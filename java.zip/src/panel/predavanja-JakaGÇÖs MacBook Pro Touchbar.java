package panel;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import javax.swing.*;

/**
 *
 * @author jakacenta
 */
public class predavanja {

    public static void main(String[] args) {
        System.out.printf("%2d %>20s" , 13, "asdasd");
    }
}

