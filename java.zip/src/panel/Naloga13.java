package panel;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import javax.swing.*;

/**
 *
 * @author jakacenta
 */
public class Naloga13 {

    public static void main(String[] args) {
        int n = 20;
        int s = 30;
        String file = "";
        List<String> list = new ArrayList<>();
        try {
            Scanner sc = new Scanner(new File("viri/abc.txt"));
            while (sc.hasNext()) {
                file += sc.nextLine();
            }
            String[] words = file.trim().split(" ");
            String line = "";
            for (int i = 0; i < words.length; i++) {
                if (line.length() + words[i].length() + 1 <= n) {
                    if (line.length() == 0) {
                        line = line + words[i];
                    } else {
                        line = line + " " + words[i];
                    }

                } else {
                    int pike = (s - line.length()) / 2;
                    if ((s - line.length()) % 2 == 0) {
                        for (int j = 0; j < pike; j++) {
                            System.out.print(".");
                        }
                        System.out.print(line);
                        for (int j = 0; j < pike; j++) {
                            System.out.print(".");
                        }
                    } else {
                        for (int j = 0; j < pike; j++) {
                            System.out.print(".");
                        }
                        System.out.print(line);
                        for (int j = 0; j <= pike; j++) {
                            System.out.print(".");
                        }
                    }
                    System.out.println("");
                    line = words[i];
                }
            }
        } catch (Exception e) {
            e.getMessage();
        }

    }
}
