/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package panel;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.event.*;
import java.io.*;
import java.util.Random;
import java.util.Scanner;
import java.util.*;
import javax.swing.*;

/**
 *
 * @author jaka
 */
class Student1 {

    String ime;
    int id;
    int ocena;

    public Student(String ime, int id) {
        this.ime = ime;
        this.id = id;
    }

    public void setOcena(int ocena) {
        this.ocena = ocena;
    }

}

public class vaja {

    static Map<Integer, Student> s = new TreeMap<>();

    public static void main(String[] args) throws Exception {
        preberiS();
        preberio();

        List<Integer> stu = new ArrayList<>(s.keySet());

        Collections.sort(stu, new Comparator<Integer>() {
            @Override
            public int compare(Integer o1, Integer o2) {
                return s.get(o1).ime.compareTo(s.get(o2).ime);
            }
        });
        for (Integer a : stu) {
            System.out.println(s.get(a).ime + "   " + s.get(a).ocena);
        }

    }

    static void preberiS() throws Exception {
        Scanner sc = new Scanner(new File("viri/studenti.txt"));
        while (sc.hasNextLine()) {
            String[] line = sc.nextLine().trim().split(":");
            s.put(Integer.parseInt(line[0]), new Student(line[1], Integer.parseInt(line[0])));
        }
        sc.close();
    }

    static void preberio() throws Exception {
        Scanner sc = new Scanner(new File("viri/ocene.txt"));
        while (sc.hasNextLine()) {
            String[] line = sc.nextLine().trim().split(":");
            //System.out.println(Arrays.toString(line));
            Student tmp = s.get(Integer.parseInt(line[0]));
            tmp.ocena = Integer.parseInt(line[1]);
            s.put(Integer.parseInt(line[0]), tmp);
        }
        sc.close();
    }

}
