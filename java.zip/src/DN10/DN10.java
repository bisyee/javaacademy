//package DN10;

import java.io.File;
import java.util.Scanner;

interface OblikovalecBesedila {

    String oblikujBesedilo(String vrstica);
}

class OblikaNaslova implements OblikovalecBesedila {

    @Override
    public String oblikujBesedilo(String vrstica) {
        String[] stavek = vrstica.split(" ");
        String novStavek = "";

        for (int i = 0; i < stavek.length; i++) {
            if (stavek[i].length() != 0) {
                novStavek += (Character.toUpperCase(stavek[i].charAt(0)));
                novStavek += (stavek[i].substring(1)).toLowerCase() + " ";
            }
        }
        return novStavek;
    }
}

class OblikaStavka implements OblikovalecBesedila {

    boolean locilo = true;

    @Override
    public String oblikujBesedilo(String vrstica) {
        vrstica = vrstica.toLowerCase();
        String novaVrstica = "";
        for (int i = 0; i < vrstica.length(); i++) {
            if (vrstica.charAt(i) == '.') {
                novaVrstica += '.';
                locilo = true;
            } else if (vrstica.charAt(i) >= 'a' && vrstica.charAt(i) <= 'z' && locilo) {
                novaVrstica += vrstica.toUpperCase().charAt(i);
                locilo = false;
            } else {
                novaVrstica += vrstica.charAt(i);
            }
        }
        return novaVrstica;
    }
}

class OblikovanjeBesedila {

    /*
        bere vrstice iz datoteke, vsako vrstico preoblikuje z oblikovalcem kateri je ustvarjen v main metodi.
        Izpise oblikovano vrstico
     */
    public static void oblikujBesedilo(String imeDatoteke, OblikovalecBesedila oblikovalec) throws Exception {
        Scanner sc = new Scanner(new File(imeDatoteke));

        String vrstica;
        while (sc.hasNextLine()) {
            vrstica = sc.nextLine();
            vrstica = oblikovalec.oblikujBesedilo(vrstica);
            System.out.println(vrstica);
        }
    }
}

public class DN10 {

    public static void main(String[] args) throws Exception {

        /*
          glede na prvi argument se ustvari oblikovalec za naslov ali stavek
         */
        if (args[0].equals("OblikaNaslova")) {
            OblikovanjeBesedila.oblikujBesedilo(args[1], new OblikaNaslova());
        } else if (args[0].equals("OblikaStavka")) {
            OblikovanjeBesedila.oblikujBesedilo(args[1], new OblikaStavka());
        }
    }

}
