//package DN6;

/**
 *
 * @author jakacenta
 */

import java.util.Scanner;
import java.io.File;

public class DN06 {

    public static void main(String[] args) throws Exception {
        String niz;
        Scanner sc = new Scanner(new File(args[0]));
        while (sc.hasNext()) {
            niz = sc.next();
            if (niz.length() % 8 == 0) {
                for (int i = 0; i < niz.length() / 8; i++) {
                    System.out.print((char) BinDec(niz.substring(i * 8, (i + 1) * 8)));
                }
            }
        }

    }

    static int BinDec(String bin) {
        int dec = 0;
        int b = 1;
        for (int i = bin.length() - 1; i >= 0; i--) {
            dec += bin.charAt(i) == '1' ? b : 0;
            b = b << 1;
        }
        return dec;
    }

}
