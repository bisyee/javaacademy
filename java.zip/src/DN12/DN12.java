//package DN12;

import java.io.File;
import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author jaka
 */
public class DN12 {

    public static void main(String[] args) throws Exception {
        ArrayList<String> numbers = new ArrayList<>();
        numbers = readFile(args[0]);

        if (args[2].equals("x")) {
            printNumbersAligned(numbers, Integer.parseInt(args[1]));
        } else {
            printNumbers(numbers, Integer.parseInt(args[1]));
        }
    }

    public static ArrayList<String> readFile(String imeDatoteke) throws Exception {
        ArrayList<String> numbers = new ArrayList<>();
        Scanner sc = new Scanner(new File(imeDatoteke));
        while (sc.hasNext()) {
            numbers.add(sc.next());
        }
        return numbers;
    }

    public static void printNumbers(ArrayList<String> numbers, int lineLength) {
        String line = "";
        for (int i = 0; i < numbers.size(); i++) {
            if (lineLength - line.length() - numbers.get(i).length() > 0) {
                if (line.length() == 0) {
                    line += numbers.get(i);
                } else {
                    line += " " + numbers.get(i);
                }
            } else {
                System.out.println(line);
                line = "";
                line += numbers.get(i);
            }
        }
        System.out.println(line);
    }

    public static void printNumbersAligned(ArrayList<String> numbers, int lineLength) {
        String line = "";
        int numberOfWords = 0;
        int lastLine = 0;
        for (int i = 0; i < numbers.size(); i++) {
            if (lineLength - line.length() - numbers.get(i).length() > 0) {
                if (line.length() == 0) {
                    line += numbers.get(i);
                } else {
                    line += " " + numbers.get(i);
                }
                numberOfWords++;
                if (i == numbers.size() - 1) {
                    lastLine = 1;
                }
            } else {
                System.out.println(alignedLine(line, lineLength, numberOfWords));
                line = "";
                line += numbers.get(i);
                numberOfWords = 1;
            }
        }
        System.out.println(alignedLine(line, lineLength, numberOfWords));
    }

    public static String alignedLine(String line, int lineLength, int numberOfWords) {
        String[] words = line.split(" ");
        String newLine = "";
        int spaceFields = lineLength - (line.length() - numberOfWords - 1) - 2;
        int space = spaceFields / (numberOfWords - 1);
        int extraSpaces = spaceFields - (space * (numberOfWords - 1));
        for (int j = 0; j < words.length; j++) {
            if (j == 0) {
                newLine += words[j];
            } else {
                for (int k = 0; k < space; k++) {
                    newLine += " ";
                }
                if (spaceFields % (numberOfWords - 1) != 0 && j <= extraSpaces) {
                    newLine += " ";
                }
                newLine += words[j];
            }
        }
        return newLine;
    }

}
