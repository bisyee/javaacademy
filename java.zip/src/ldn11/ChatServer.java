package ldn11;

import java.io.*;
import java.net.*;
import java.util.*;
import javax.net.ssl.*;
import java.security.*;

public class ChatServer {

    protected int port = 8888;
    protected List<Socket> clients = new ArrayList<Socket>();
    protected static HashMap<Socket, String> mapaImen = new HashMap<Socket, String>();
    String passphrase = "serverpwd";
    KeyStore clientKeyStore;
    KeyStore serverKeyStore;

    public static void main(String[] args) throws Exception {
        new ChatServer();
    }

    public ChatServer() {
        ServerSocket serverSocket = null;

        // create socket
        try {
            serverSocket = new ServerSocket(this.port);

            // preberi datoteko z odjemalskimi certifikati
            clientKeyStore = KeyStore.getInstance("JKS"); // KeyStore za shranjevanje odjemalčevih javnih ključev (certifikatov)
            clientKeyStore.load(new FileInputStream("clients.public"), "public".toCharArray());

// preberi datoteko s svojim certifikatom in tajnim ključem
            serverKeyStore = KeyStore.getInstance("JKS"); // KeyStore za shranjevanje strežnikovega tajnega in javnega ključa
            serverKeyStore.load(new FileInputStream("server.private"), passphrase.toCharArray());

        } catch (Exception e) {
            System.err.println("[system] could not create socket on port " + this.port);
            e.printStackTrace(System.err);
            System.exit(1);
        }

        // start listening
        System.out.println("[system] listening ...");
        while (true) {
            try {

// vzpostavi SSL kontekst (komu zaupamo, kakšni so moji tajni ključi in certifikati)
                TrustManagerFactory tmf = TrustManagerFactory.getInstance("SunX509");
                tmf.init(clientKeyStore);
                KeyManagerFactory kmf = KeyManagerFactory.getInstance("SunX509");
                kmf.init(serverKeyStore, passphrase.toCharArray());
                SSLContext sslContext = SSLContext.getInstance("TLS");
                sslContext.init(kmf.getKeyManagers(), tmf.getTrustManagers(), new SecureRandom());

// kreiramo socket
                SSLServerSocketFactory factory = (SSLServerSocketFactory) sslContext.getServerSocketFactory();
                SSLServerSocket ss = (SSLServerSocket) factory.createServerSocket(port);
                ss.setNeedClientAuth(true); // tudi odjemalec se MORA predstaviti s certifikatom
                ss.setEnabledCipherSuites(new String[]{"TLS_RSA_WITH_AES_128_CBC_SHA256"});
                Socket newClientSocket = serverSocket.accept();
                synchronized (this) {
                    clients.add(newClientSocket);
                    mapaImen.put(newClientSocket, "");
                }
                ChatServerConnector conn = new ChatServerConnector(this, newClientSocket);
                conn.start();
            } catch (Exception e) {
                System.err.println("[error] Accept failed.");
                e.printStackTrace(System.err);
                System.exit(1);
            }
            if (1 < 0) {
                break;
            }
        }

        System.out.println("[system] closing server socket ...");
        try {
            serverSocket.close();
        } catch (IOException e) {
            e.printStackTrace(System.err);
            System.exit(1);
        }
    }

    public void sendToOneClient(String message, Socket socket) {
        try {
            DataOutputStream out = new DataOutputStream(socket.getOutputStream());
            out.writeUTF(message);
        } catch (Exception e) {
            System.err.println("[system] could not send message to a client");
            e.printStackTrace(System.err);
        }
    }

    public void sendToAllClients(String message) throws Exception {
        Iterator<Socket> i = clients.iterator();
        while (i.hasNext()) {
            Socket socket = (Socket) i.next();
            try {
                DataOutputStream out = new DataOutputStream(socket.getOutputStream());
                out.writeUTF(message);
            } catch (Exception e) {
                System.err.println("[system] could not send message to a client");
                e.printStackTrace(System.err);
            }
        }
    }

    public void removeClient(Socket socket) {
        synchronized (this) {
            clients.remove(socket);
        }
    }
}

class ChatServerConnector extends Thread {

    private ChatServer server;
    private Socket socket;

    public ChatServerConnector(ChatServer server, Socket socket) {
        this.server = server;
        this.socket = socket;
    }

    public void run() {
        System.out.println("[system] connected with " + this.socket.getInetAddress().getHostName() + ":" + this.socket.getPort());

        DataInputStream in;
        try {
            in = new DataInputStream(this.socket.getInputStream());
        } catch (IOException e) {
            System.err.println("[system] could not open input stream!");
            e.printStackTrace(System.err);
            return;
        }

        while (1 > 0) {
            String msg_received;
            try {
                msg_received = in.readUTF(); // the message from the client
            } catch (Exception e) {
                System.err.println("[system] there was a problem while reading message from a client");
                e.printStackTrace(System.err);
                continue;
            }

            if (msg_received.length() == 0) {
                continue;
            }

            System.out.println("[RKchat] [" + this.socket.getPort() + "] : " + msg_received);
            if (msg_received.equalsIgnoreCase("exit")) {
                break;
            }

            String[] data = msg_received.split("\\|-\\|");
            String[] type = data[0].split(":");

            if (type[0].equals("private")) {
                // private messages...

                boolean jePoslal = false;
                for (Map.Entry<Socket, String> e : ChatServer.mapaImen.entrySet()) {
                    String ime = e.getValue();
                    Socket s = e.getKey();
                    if (type[2].equals(ime)) {
                        String str = data[2].split("/ ")[1];
                        this.server.sendToOneClient(type[3] + " said (private):" + str.substring(str.indexOf(" ")).toUpperCase(), s);
                        jePoslal = true;
                        break;
                    }
                }
                if (jePoslal == false) {
                    this.server.sendToOneClient("napaka pri pošiljanju: naslovnik ni prijavljen", this.socket);
                }
                //System.out.println(type[2]);
                continue;
            }

            ChatServer.mapaImen.put(this.socket, type[1]);
            //System.out.println(ChatServer.mapaImen.get(this.socket));

            if (type[1].equals(data[2])) {
                continue;
            }

            String msg_send = type[1] + " said: " + data[2].toUpperCase(); // TODO

            try {
                this.server.sendToAllClients(msg_send); // send message to all clients
            } catch (Exception e) {
                System.err.println("[system] there was a problem while sending the message to all clients");
                e.printStackTrace(System.err);
                continue;
            }
        }
        this.server.removeClient(this.socket);
        System.out.println("[system] client " + this.socket.getPort() + " exited ...");
    }
}
