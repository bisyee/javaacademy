package ldn11;

import java.io.*;
import java.net.*;
import java.util.Date;
import java.util.Scanner;
import javax.net.ssl.*;
import java.security.*;

public class ChatClient extends Thread {

    protected int port = 8888;
    protected String host;
    protected Date date = new Date();

    public static void main(String[] args) throws Exception {
        new ChatClient();
    }

    public ChatClient() throws Exception {
        //Socket socket = null;
        SSLSocket socket = null;
        DataInputStream in = null;
        DataOutputStream out = null;
        String passphrase = "clientpassword";

        // connect to the chat server
        try {
            Scanner sc = new Scanner(System.in);
            System.out.print("Vpiši svoje ime (brez presledka in dvopičja!): ");
            host = sc.next();
            System.out.println("");

            // preberi datoteko s strežnikovim certifikatom
            KeyStore serverKeyStore = KeyStore.getInstance("JKS");
            serverKeyStore.load(new FileInputStream("server.public"), "public".toCharArray());

// preberi datoteko s svojim certifikatom in tajnim ključem
            KeyStore clientKeyStore = KeyStore.getInstance("JKS");
            clientKeyStore.load(new FileInputStream("client.private"), passphrase.toCharArray());

// vzpostavi SSL kontekst (komu zaupamo, kakšni so moji tajni ključi in certifikati)
            TrustManagerFactory tmf = TrustManagerFactory.getInstance("SunX509");
            tmf.init(serverKeyStore);
            KeyManagerFactory kmf = KeyManagerFactory.getInstance("SunX509");
            kmf.init(clientKeyStore, passphrase.toCharArray());
            SSLContext sslContext = SSLContext.getInstance("TLS");
            sslContext.init(kmf.getKeyManagers(), tmf.getTrustManagers(), new SecureRandom());

// kreiramo socket
            SSLSocketFactory sf = sslContext.getSocketFactory();
            socket = (SSLSocket) sf.createSocket(host, port);
            socket.setEnabledCipherSuites(new String[]{"TLS_RSA_WITH_AES_128_CBC_SHA256"}); // dovoljeni nacin kriptiranja (CipherSuite)
            socket.startHandshake(); // eksplicitno sprozi SSL Handshake

            System.out.println("[system] connecting to chat server ...");
            //socket = new Socket("localhost", serverPort);
            in = new DataInputStream(socket.getInputStream());
            out = new DataOutputStream(socket.getOutputStream());

            ChatClientMessageReceiver message_receiver = new ChatClientMessageReceiver(in);
            message_receiver.start();

            this.sendMessage(host, out);

        } catch (Exception e) {
            e.printStackTrace(System.err);
            System.exit(1);
        }

        // read from STDIN and send messages to the chat server
        BufferedReader std_in = new BufferedReader(new InputStreamReader(System.in));
        String userInput;
        while ((userInput = std_in.readLine()) != null) {
            this.sendMessage(userInput, out);
        }

        // cleanup
        out.close();
        in.close();
        std_in.close();
        socket.close();
    }

    private void sendMessage(String message, DataOutputStream out) {
        try {
            String structured = "";
            if (message.split("/")[0].equals("zasebno")) {
                structured = "private:receiver:" + message.split(" ")[1] + ":";
            } else {
                structured = "sendToAll:";
            }
            structured += host + "|-|" + date.toString() + "|-|" + message;
            out.writeUTF(structured);
            out.flush();
        } catch (IOException e) {
            System.err.println("[system] could not send message");
            e.printStackTrace(System.err);
        }
    }
}

// wait for messages from the chat server and print the out
class ChatClientMessageReceiver extends Thread {

    private DataInputStream in;

    public ChatClientMessageReceiver(DataInputStream in) {
        this.in = in;
    }

    public void run() {
        try {
            String message;
            while ((message = this.in.readUTF()) != null) {
                System.out.println("[RKchat] " + message);
            }
        } catch (Exception e) {
            System.err.println("[system] could not read message");
            e.printStackTrace(System.err);
        }
    }
}
