public class V_02{
	public static void main(String[] args) {
		System.out.println(fakultetaL(20));
		System.out.println(stirlingL(20));
		napaka();
		System.out.println();

		//long je premajhen na 21

		System.out.println(fakultetaD(21));
		System.out.println(stirlingD(21));
		napakaD();
	}

	public static long fakultetaL(int n){
		long resoult=1;
		for(int i = 1; i <=n;i++){
			resoult*=i;
		}
		return resoult;
	}

	public static long stirlingL(int n){
		return Math.round(Math.sqrt(2*Math.PI*n)*Math.pow((n/Math.E),n));
	}

	public static void napaka() {
		System.out.println("  n            n!               Stirling(n)         napaka (%)");
		System.out.println("--------------------------------------------------------------");
		float napaka;
		long fak;
		long sti;
		for (int i = 1; i <= 20; i++) {
			fak = fakultetaL(i);
			sti = stirlingL(i);
			napaka = (float)Math.abs(fak - sti)/fak*100;
			System.out.printf("%3d %19d %19d         %.7f\n", i, fak, sti, napaka);
		}
	}

	public static double fakultetaD(int n){
		double resoult=1;
		for(int i = 1; i <=n;i++){
			resoult*=i;
		}
		return resoult;
	}

	public static double stirlingD(int n){
		return Math.sqrt(2*Math.PI*n)*Math.pow((n/Math.E),n);
	}

	public static void napakaD() {
		System.out.println("  n            n!               Stirling(n)         napaka (%)");
		System.out.println("--------------------------------------------------------------");
		double napaka;
		double fak;
		double sti;
		for (int i = 1; i <= 100; i++) {
			fak = fakultetaD(i);
			sti = stirlingD(i);
			napaka = (double)Math.abs(fak - sti)/fak*100;
			System.out.printf("%3d %20.9E %20.9E       %.7f\n", i, fak, sti, napaka);
		}
	}


}