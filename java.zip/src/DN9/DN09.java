//package DN9;

import java.util.Scanner;
import java.io.File;
import java.util.Arrays;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.text.ParseException;
import java.util.Calendar;

public class DN09 {

    public enum Months {
        Januar, Februar, Marec, April, Maj, Junij, Julij, Avgust, September, Oktober, November, December
    }

    public static void main(String[] args) throws Exception {
        try {
            Meritev[] meritve = branje(args[1]);

            if (args[0].equals("3")) {
                povprecnaTempNaPostaji(meritve, Integer.parseInt(args[2]), args[3], args[4]);
            } else if (args[0].equals("4")) {
                izpisPopolnihMeritev(meritve, Integer.parseInt(args[2]));
            } else if (args[0].equals("5")) {
                povprecnaTempPoMesecih(meritve, Integer.parseInt(args[2]));
            } else if (args[0].equals("7")) {
                preberiZapisovalce(args[1], args[2], args[3]);
            } else if (args[0].equals("6")) {
                povp_tedni(meritve, args[2], Integer.parseInt(args[3]), args[4]);
            }

        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    public static void povp_tedni(Meritev[] meritve, String datum, int stTednov, String mestaS) throws Exception {
        String[] mesta = mestaS.split(",");
        System.out.print("         ");
        int k = 0;
        while (k < mesta.length) {
            System.out.printf("%10s", mesta[k]);
            k++;
        }
        SimpleDateFormat format = new SimpleDateFormat("dd.MM.yyyy");
        double povp;
        int count;
        Date date1, date2;
        String[] tmp = datum.split("\\.");
        for (int i = 0; i < stTednov; i++) {
            System.out.printf("\n%d.teden", i + 1);
            datum = String.format("%d.%s.%s", Integer.parseInt(tmp[0]) + 7 * (i + 1), tmp[1], tmp[2]);
            date1 = format.parse(datum);
            datum = String.format("%d.%s.%s", Integer.parseInt(tmp[0]) + 7 * i, tmp[1], tmp[2]);
            date2 = format.parse(datum);
            for (int j = 0; j < mesta.length; j++) {
                count = 0;
                povp = 0;
                for (int h = 0; h < meritve.length; h++) {
                    if (meritve[h] == null) {
                        break;
                    }
                    if (meritve[h].mesto.equals(mesta[j]) && (meritve[h].datum.after(date2) || meritve[h].datum.equals(date2)) && (meritve[h].datum.before(date1))) {
                        povp += meritve[h].temperatura;
                        count++;
                    }
                }
                System.out.printf("%10.1f", (povp / count));
            }
        }
    }

    public static String[] vsaImenaZapisovalcev(String ImeDat) throws Exception {
        String[] imena = new String[100];
        Scanner sc = new Scanner(new File(ImeDat));

        String line;
        String[] data;
        int id;
        int i = 0;

        while (sc.hasNextLine()) {
            line = sc.nextLine();
            data = line.split(":");

            id = Integer.parseInt(data[0]);
            if (id <= 199 && id >= 100 && data.length == 5 && !Arrays.toString(data).contains("?")) {
                if (!Arrays.toString(imena).contains(data[2])) {
                    imena[i++] = data[2];
                }
            }
        }
        Arrays.sort(imena, 0, i);
        return imena;
    }

    public static void preberiZapisovalce(String ImeDat, String datumOd, String datumDo) throws Exception {
        Scanner sc = new Scanner(new File(ImeDat));
        SimpleDateFormat formatter = new SimpleDateFormat("dd.MM.yyyy");
        Zapisovalec[] zapisovalci = new Zapisovalec[100];
        String[] imena = vsaImenaZapisovalcev(ImeDat);

        String line;
        String[] data;
        int id;
        int i = 0;
        int k = 0;

        //ustvari objekte oseb po abecedi
        for (int j = 0; j < imena.length; j++) {
            if (imena[j] != null) {
                zapisovalci[k++] = new Zapisovalec(imena[j]);
            }
        }

        //doda meritve osebam
        while (sc.hasNextLine()) {
            line = sc.nextLine();
            data = line.split(":");

            id = Integer.parseInt(data[0]);
            if (id <= 199 && id >= 100 && data.length == 5 && !Arrays.toString(data).contains("?")) {
                for (int j = 0; j < zapisovalci.length; j++) {
                    if (zapisovalci[j].Ime.equals(data[2])) {
                        for (int l = 0; l < zapisovalci[j].meritve.length; l++) {
                            if (zapisovalci[j].meritve[l] == null) {
                                zapisovalci[j].meritve[l] = new RocnaMeritev(Integer.parseInt(data[0]), data[1], data[2], formatter.parse(data[3]), Double.parseDouble(data[4]));
                                break;
                            }
                        }
                        break;
                    }
                }
            }
        }

        Date datumod = formatter.parse(datumOd);
        Date datumdo = formatter.parse(datumDo);

        System.out.println("Zapisovalec       Zanesljivost");
        for (int j = 0; j < zapisovalci.length; j++) {
            if (zapisovalci[j] != null) {
                System.out.printf("%-10s            %.2f\n", zapisovalci[j].Ime, zapisovalci[j].Zanesljivost(datumod, datumdo));
            }
        }
    }

    public static void povprecnaTempPoMesecih(Meritev[] m, int leto) throws Exception {

        m = bubbleSortPoDatumu(m);
        int mesec = 0; // januar  = 0
        double sumTemp = 0;
        int n = 0;
        int i = 0;

        System.out.printf("Povprecna temperatura po mesecih leta %d\n", leto);

        while (i < m.length) {
            if (m[i] != null && m[i].datum.getYear() + 1900 == leto) {
                if (m[i].datum.getMonth() == mesec) {
                    sumTemp += m[i].temperatura;
                    n++;
                    i++;
                } else {
                    System.out.printf("%-10s %10.1f \n", Months.values()[mesec] + ":", sumTemp / n);
                    mesec++;
                    sumTemp = 0;
                    n = 0;
                }
                if (m[i] == null && mesec == 11) {
                    System.out.printf("%-10s %10.1f \n", Months.values()[mesec] + ":", sumTemp / n);
                    break;
                }
            }
        }
    }

    public static Meritev[] bubbleSortPoDatumu(Meritev[] meritev) throws ParseException {
        SimpleDateFormat formatter = new SimpleDateFormat("dd.MM.yyyy");
        int n = meritev.length;
        int k;
        for (int m = n; m >= 0; m--) {
            for (int i = 0; i < n - 1; i++) {
                k = i + 1;
                if (meritev[i] != null && meritev[k] != null && meritev[i].datum.after(meritev[k].datum)) {
                    if (meritev[i].id <= 99) {
                        AvtomatskaMeritev temp = (AvtomatskaMeritev) meritev[i];
                        meritev[i] = meritev[k];
                        meritev[k] = temp;
                    } else if (meritev[i].id >= 100) {
                        RocnaMeritev temp = (RocnaMeritev) meritev[i];
                        meritev[i] = meritev[k];
                        meritev[k] = temp;
                    }
                }
            }
        }
        return meritev;
    }

    public static void izpisPopolnihMeritev(Meritev[] m, int id) throws ParseException {
        SimpleDateFormat formatter = new SimpleDateFormat("dd.MM.yyyy");
        m = bubbleSortPoDatumu(m);
        System.out.printf("Popolne meritve na merilni postaji %s so:\n", id);
        for (int i = 0; i < m.length; i++) {
            if (m[i] != null) {
                if (m[i].id == id) {
                    System.out.printf("%s:     %5.1f\n", formatter.format(m[i].datum), m[i].temperatura);
                }
            }
        }
    }

    public static void povprecnaTempNaPostaji(Meritev[] m, int id, String datumOd, String datumDo) throws ParseException {
        SimpleDateFormat formatter = new SimpleDateFormat("dd.MM.yyyy");

        Date datumod = formatter.parse(datumOd);
        Date datumdo = formatter.parse(datumDo);
        datumdo.setSeconds(1);

        double sumTemp = 0;
        int n = 0;

        for (int i = 0; i < m.length; i++) {
            if (m[i] != null) {
                Date temp = m[i].datum;
                temp.setSeconds(1);
                if (m[i].id == id && datumod.before(temp) && datumdo.after(m[i].datum)) {
                    n++;
                    sumTemp += m[i].temperatura;
                }
            }
        }
        System.out.printf("Povprecna temperatura merilnega mesta %d za obdobje od %s do %s je %.1f stopinj celzija.", id, datumOd, datumDo, sumTemp / n);
    }

    public static Meritev[] branje(String ImeDat) throws Exception {
        Meritev[] meritve = new Meritev[10000];
        Scanner sc = new Scanner(new File(ImeDat));
        SimpleDateFormat formatter = new SimpleDateFormat("dd.MM.yyyy");

        String line;
        int id;
        int i = 0;
        String[] data;

        while (sc.hasNextLine()) {
            line = sc.nextLine();
            data = line.split(":");

            id = Integer.parseInt(data[0]);
            if (id <= 99 && id >= 0 && data.length == 5) {
                meritve[i++] = new AvtomatskaMeritev(Integer.parseInt(data[0]), data[1], formatter.parse(data[2]), data[3], Double.parseDouble(data[4]));
            } else if (id <= 199 && id >= 100 && data.length == 5 && !Arrays.toString(data).contains("?")) {
                meritve[i++] = new RocnaMeritev(Integer.parseInt(data[0]), data[1], data[2], formatter.parse(data[3]), Double.parseDouble(data[4]));
            }
        }
        return meritve;
    }

}

class Meritev {

    int id;
    String mesto;
    Date datum;
    double temperatura;

    Meritev() {
        this.id = 0;
        this.mesto = "";
        this.datum = new Date();
        this.temperatura = 0;
    }

    Meritev(int id, String mesto, Date datum, double temperatura) {
        this.id = id;
        this.mesto = mesto;
        this.datum = datum;
        this.temperatura = temperatura;
    }

}

class AvtomatskaMeritev extends Meritev {

    String ura;

    AvtomatskaMeritev() {
        super();
        this.ura = "";
    }

    AvtomatskaMeritev(int id, String mesto, Date datum, String ura, double temperatura) {
        super(id, mesto, datum, temperatura);
        this.ura = ura;
    }

}

class RocnaMeritev extends Meritev {

    String zapisovalec;

    RocnaMeritev() {
        super();
        this.zapisovalec = "";
    }

    RocnaMeritev(int id, String mesto, String zapisovalec, Date datum, double temperatura) {
        super(id, mesto, datum, temperatura);
        this.zapisovalec = zapisovalec;
    }

}

class Zapisovalec {

    String Ime;
    Meritev[] meritve = new Meritev[10000];

    public Zapisovalec(String ime) {
        this.Ime = ime;
    }

    public double Zanesljivost(Date datumOd, Date datumDo) {
        long diff = Math.round((datumDo.getTime() - datumOd.getTime()) / (double) 86400000);
        int c = 0;
        for (int i = 0; i < this.meritve.length; i++) {
            if (this.meritve[i] != null && (this.meritve[i].datum.after(datumOd) || this.meritve[i].datum.equals(datumOd)) && (this.meritve[i].datum.before(datumDo) || this.meritve[i].datum.equals(datumDo))) {
                c++;
            }
        }
        return (double) c / (diff + 1);
    }
}
