
package V_08;

import java.util.Scanner;
import java.io.File;
import java.io.IOException;


public class V_08 {

    public static Komponenta[] readFile(String ime) {

        Komponenta[] komponente = new Komponenta[100];
        int popustPomnilnik = 10;
        int popustMaticna = 15;
        int popustProcesor = 5;

        try {
            Scanner scan = new Scanner(new File(ime));
            String line;
            String[] args;
            int i = 0;
            while (scan.hasNextLine()) {
                line = scan.nextLine();
                args = line.split(";");
                if (args.length == 6) {
                    if (args[0].equals("Pomnilnik")) {
                        komponente[i] = new Pomnilnik(args[1], Double.parseDouble(args[2]), popustPomnilnik,Integer.parseInt(args[3]), Integer.parseInt(args[4]), Integer.parseInt(args[5]));
                    } else if (args[0].equals("Procesor")) {
                        komponente[i] = new Procesor(args[1], Double.parseDouble(args[2]), popustProcesor, args[3], Integer.parseInt(args[4]), Integer.parseInt(args[5]));
                    } else if (args[0].equals("Maticna")) {
                        komponente[i] = new MaticnaPlosca(args[1], Double.parseDouble(args[2]), popustMaticna, args[3], args[4], Integer.parseInt(args[5]));
                    }
                    i++;
                }
            }
        } catch (IOException e) {
            System.out.println(e);
        }

        return komponente;
    }
    
    public static void izpisi (Komponenta[] komponente) {
        for (int i = 0; i < komponente.length; i++) {
            if (komponente[i] != null) {
                System.out.println(komponente[i]);
                System.out.println();
            }
        }
    }
    
    public static void kompatibilneKomponente(Komponenta[] komponente) {
        for (int i = 0; i < komponente.length; i++) {
            if (komponente[i] instanceof MaticnaPlosca) {
                for (int j = 0; j < komponente.length; j++) {
                    if(komponente[j] instanceof Procesor && ((MaticnaPlosca) komponente[i]).jeKompatibilna((Procesor) komponente[j])) {
                        System.out.println(String.format("Procesor: %s in maticna plosca: %s sta kompatibilna (podnozje %s).", komponente[j].getIme(), komponente[i].getIme(), ((Procesor)komponente[j]).getPodnozje()));
                    }
                }
            }
        }
    }

    public static void main(String[] args) {
        Komponenta[] komponente = readFile("viri/komponente.txt");
        izpisi(komponente);
        kompatibilneKomponente(komponente);
    }

}

class Komponenta {

    private String ime;
    private double cena;
    private int popust;

    public Komponenta(String ime, double cena, int popust) {
        this.ime = ime;
        this.cena = cena;
        this.popust = popust;
    }

    public String toString() {
        return String.format("%s, cena s popustom: %.2f\n", this.ime, this.cenaSPopustom());
    }

    public double cenaSPopustom() {
        return this.cena * (100 - this.popust) / 100;
    }
    
    public String getIme() {
        return this.ime;
    }

}

class Pomnilnik extends Komponenta {

    String TIPI[] = {"SDRAM", "DDR", "DDR2", "DDR3"};
    private int tip;
    private int velikost;
    private int hitrost;

    public Pomnilnik(String ime, double cena, int popust, int tip, int velikost, int hitrost) {
        super(ime, cena, popust);
        this.tip = tip;
        this.velikost = velikost;
        this.hitrost = hitrost;
    }

    public String toString() {
        return "Pomnilnik: " + super.toString() + String.format("Tip: %s, velikost: %dGB, hitrost: %dMHz", this.TIPI[this.tip], this.velikost, this.hitrost);
    }

}

class MaticnaPlosca extends Komponenta {

    private String format;
    private String podnozje;
    private int steviloPomnilniskihRez;

    public MaticnaPlosca(String ime, double cena, int popust, String format, String podnozje, int steviloPomnilniskihRez) {
        super(ime, cena, popust);
        this.format = format;
        this.podnozje = podnozje;
        this.steviloPomnilniskihRez = steviloPomnilniskihRez;
    }

    public String toString() {
        return "Maticna plosca: " + super.toString() + String.format("Format: %s, podnozje: %s, stevilo pomn. rez: %d", this.format, this.podnozje, this.steviloPomnilniskihRez);
    }

    public boolean jeKompatibilna(Procesor p) {
        return this.podnozje.equals(p.getPodnozje());
    }

}

class Procesor extends Komponenta {

    private String podnozje;
    private int steviloJeder;
    private int hitrostJedra;

    public Procesor(String ime, double cena, int popust, String podnozje, int steviloJeder, int hitrostJedra) {
        super(ime, cena, popust);
        this.podnozje = podnozje;
        this.steviloJeder = steviloJeder;
        this.hitrostJedra = hitrostJedra;
    }

    public String toString() {
        return "Procesor: " + super.toString() + String.format("Podnozje: %s, st. jeder: %d, hitrost jedra: %dMHz", this.podnozje, this.steviloJeder, this.hitrostJedra);
    }

    public String getPodnozje() {
        return this.podnozje;
    }

}