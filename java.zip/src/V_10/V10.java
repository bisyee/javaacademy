/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package V_10;

import java.io.File;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.TreeMap;
import java.util.TreeSet;

/**
 *
 * @author jakacenta
 */
public class V10 {
    public static void main(String[] args)throws Exception {
        MrezaLetov m = new MrezaLetov();
        m.preberiLetalisca(new File("viri/letalisca.txt"));
        m.preberiPovezave(new File("viri/poleti.txt"));
        m.izpisi();
        
    }
    
}

class Letalisce{
    private String id;
    private String mesto;
    private String drzava;
    private ArrayList<String> prihod = new ArrayList<>();
    private ArrayList<String> odhod = new ArrayList<>();

    public Letalisce(String id, String mesto, String drzava) {
        this.id = id;
        this.mesto = mesto;
        this.drzava = drzava;
    }

    @Override
    public String toString() {
        String line = "";
        line += String.format("%s: %s, %s", this.id, this.mesto, this.drzava);
        line += "\n   prihodi iz:";
        for (String pri : this.prihod) {
            line += " " + pri;
        }
        line += "\n   odhodi v:";
        for (String odh : this.odhod) {
            line += " " + odh;
        }
        return line;
    }

    public String getId() {
        return id;
    }

    public String getMesto() {
        return mesto;
    }

    public String getDrzava() {
        return drzava;
    }

    public void addOdhod(String ime) {
        odhod.add(ime);
    }
    
    public void addPrihod(String ime) {
        prihod.add(ime);
    }
    
    public TreeSet<String> dosegljivo(int p){
        TreeSet<String> destinacije = new TreeSet();
        destinacije.add(this.getMesto());
        return destinacije;
    
    }
    
}

class MrezaLetov {
    private TreeMap<String, Letalisce> letalisca = new TreeMap<>();

    public void addLetalisce(Letalisce l){
        this.letalisca.put(l.getId(), l);
    }
    
    public Letalisce getLetalisce(String ime) {
        return this.letalisca.get(ime);
    }
    
    public void preberiLetalisca(File f)throws Exception{
        Scanner sc = new Scanner(f);
        String[] line;
        while(sc.hasNextLine()){
            line=sc.nextLine().split(" ");
            this.addLetalisce(new Letalisce(line[0],line[1],line[2]));
        }
    }
    
    public void izpisi(){
        for (String key : letalisca.keySet()) {
            System.out.println(letalisca.get(key));
        }
    }
    
    public void preberiPovezave(File f)throws Exception{
        Scanner sc = new Scanner(f);
        String[] line;
        while(sc.hasNextLine()){
            line=sc.nextLine().split(" ");
            letalisca.get(line[0]).addOdhod(line[1]);
            letalisca.get(line[0]).addPrihod(line[1]);
            letalisca.get(line[1]).addPrihod(line[0]);
            letalisca.get(line[1]).addOdhod(line[0]);
        }
    }
}
