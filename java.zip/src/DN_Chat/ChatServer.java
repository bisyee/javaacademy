
import java.io.*;
import java.net.*;
import java.util.*;

public class ChatServer {

    protected int serverPort = 1235;
    protected List<Socket> clients = new ArrayList<Socket>(); // list of clients
    protected Map clientPort = new HashMap();

    public static void main(String[] args) throws Exception {
        new ChatServer();
    }

    public ChatServer() {
        ServerSocket serverSocket = null;

        // create socket
        try {
            serverSocket = new ServerSocket(this.serverPort); // create the ServerSocket
        } catch (Exception e) {
            System.err.println("[system] could not create socket on port " + this.serverPort);
            e.printStackTrace(System.err);
            System.exit(1);
        }

        // start listening for new connections
        System.out.println("[system] listening ...");
        try {
            while (true) {
                Socket newClientSocket = serverSocket.accept(); // wait for a new client connection
                synchronized (this) {
                    clients.add(newClientSocket); // add client to the list of clients
                }
                ChatServerConnector conn = new ChatServerConnector(this, newClientSocket); // create a new thread for communication with the new client
                conn.start(); // run the new thread
            }
        } catch (Exception e) {
            System.err.println("[error] Accept failed.");
            e.printStackTrace(System.err);
            System.exit(1);
        }

        // close socket
        System.out.println("[system] closing server socket ...");
        try {
            serverSocket.close();
        } catch (IOException e) {
            e.printStackTrace(System.err);
            System.exit(1);
        }
    }

    // send a message to all clients connected to the server
    public void sendToAllClients(String message) throws Exception {
        Iterator<Socket> i = clients.iterator();
        while (i.hasNext()) { // iterate through the client list
            Socket socket = (Socket) i.next(); // get the socket for communicating with this client
            try {
                DataOutputStream out = new DataOutputStream(socket.getOutputStream()); // create output stream for sending messages to the client
                out.writeUTF(message); // send message to the client
            } catch (Exception e) {
                System.err.println("[system] could not send message to a client");
                e.printStackTrace(System.err);
            }
        }
    }

    public void sendToClient(String message, String recipient) throws Exception {
        Iterator<Socket> i = clients.iterator();
        while (i.hasNext()) { // iterate through the client list
            Socket socket = (Socket) i.next(); // get the socket for communicating with this client
            if (socket.getPort() == (int) this.clientPort.get(recipient)) {
                try {
                    DataOutputStream out = new DataOutputStream(socket.getOutputStream()); // create output stream for sending messages to the client
                    out.writeUTF(message); // send message to the client
                } catch (Exception e) {
                    System.err.println("[system] could not send message to a client");
                    e.printStackTrace(System.err);
                }
            }
        }
    }

    public void removeClient(Socket socket) {
        synchronized (this) {
            clients.remove(socket);
        }
    }

    public void printClients(Socket socket) {
        Iterator<Socket> i = clients.iterator();
        while (i.hasNext()) {
            System.out.println((Socket) i.next());
        }
    }
}

class ChatServerConnector extends Thread {

    private ChatServer server;
    private Socket socket;

    public ChatServerConnector(ChatServer server, Socket socket) {
        this.server = server;
        this.socket = socket;
    }

    public void run() {
        System.out.println("[system] connected with " + this.socket.getInetAddress().getHostName() + ":" + this.socket.getPort());
        //this.server.printClients(socket);
        DataInputStream in;
        try {
            in = new DataInputStream(this.socket.getInputStream()); // create input stream for listening for incoming messages
        } catch (IOException e) {
            System.err.println("[system] could not open input stream!");
            e.printStackTrace(System.err);
            this.server.removeClient(socket);
            return;
        }

        while (true) { // infinite loop in which this thread waits for incoming messages and processes them
            String msg_received;
            Object delKey = "";
            try {
                msg_received = in.readUTF(); // read the message from the client
            } catch (Exception e) {
                System.err.println("[system] there was a problem while reading message client on port " + this.socket.getPort());
                this.server.removeClient(this.socket);
                for (Object key : this.server.clientPort.keySet()) {
                    if (this.server.clientPort.get(key).equals(this.socket.getPort())) {
                        delKey = key;
                    }
                }
                this.server.clientPort.remove(delKey);
                return;
            }

            if (msg_received.length() == 0) // invalid message
            {
                continue;
            }

            //add client name and port into dictionary
            String[] msg = msg_received.split(";|=");
            if (msg[0].equals("clientName")) {
                this.server.clientPort.put(msg[1], this.socket.getPort());
            } else if (msg[0].equals("user")) {
                System.out.println("[RKchat] [" + this.socket.getPort() + "] : " + msg[5]);
                String msg_send = String.format("%s %s said: %s", msg[7], msg[1], msg[5]);
                if (msg[3].equals("public")) {
                    try {
                        this.server.sendToAllClients(msg_send); // send message to all clients
                    } catch (Exception e) {
                        System.err.println("[system] there was a problem while sending the message to all clients");
                        e.printStackTrace(System.err);
                        continue;
                    }
                } else {
                    if (!this.server.clientPort.containsKey(msg[3])) {
                        try {
                            this.server.sendToClient("User offline!", msg[1]); // send message client
                        } catch (Exception e) {
                            System.err.printf("[system] there was a problem while sending the message to %s", msg[1]);
                            e.printStackTrace(System.err);
                            continue;
                        }

                    } else {
                        try {
                            this.server.sendToClient(msg_send, msg[3]); // send message client
                        } catch (Exception e) {
                            System.err.printf("[system] there was a problem while sending the message to %s", msg[3]);
                            e.printStackTrace(System.err);
                            continue;
                        }
                    }
                }
            }
        }
    }
}
