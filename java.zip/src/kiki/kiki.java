package kiki;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import javax.swing.JFrame;
import javax.swing.JPanel;
import java.io.*;
import java.util.*;

class Napakapodpis extends Exception {

    private String msg;
    private String format;

    public Napakapodpis(String format, String msg) {
        this.msg = msg;
        this.format = format;
    }

    @Override
    public String getMessage() {
        return "Datoteka ni v formatu" + this.format + ": " + this.msg;
    }
}

class NapakaIme extends Exception {

    private String msg;

    public NapakaIme(String msg) {
        this.msg = msg;
    }

    @Override
    public String getMessage() {
        return this.msg;
    }
}

class Piksel {

    private int rdeca;
    private int zelena;
    private int modra;

    Piksel(int r, int g, int b) {
        this.rdeca = r;
        this.zelena = g;
        this.modra = b;
    }

    int[] getKomponente() {
        int[] x = {this.rdeca, this.zelena, this.modra};
        return x;
    }
}

class Slika {

    private int sirina;
    private int visina;
    private String imedat;
    private Piksel[][] piksli;

    Slika(String ime, int dat) throws Exception {
        Slika a;
        if (dat == 1) {
            a = branjet(ime);
        } else {
            a = branjeb(ime);
        }
        vpni(a);
    }

    Slika(int s, int v, String ime) {
        super();
        this.sirina = s;
        this.visina = v;
        this.imedat = ime;
        piksli = new Piksel[this.visina][this.sirina];
    }

    void filaj(int x, int y, Piksel p) {
        piksli[y][x] = p;
    }

    void vpni(Slika a) {
        this.imedat = a.imedat;
        this.sirina = a.sirina;
        this.visina = a.visina;
        this.piksli = a.piksli;
    }

    float povprecje() {
        Piksel a;
        float povp = 0;
        int vsota;
        int st = 0;
        int[] vs = new int[3];
        for (int i = 0; i < this.piksli.length; i++) {
            for (int j = 0; j < this.piksli[i].length; j++) {
                vsota = 0;
                a = this.piksli[i][j];
                vs = a.getKomponente();
                for (int k = 0; k < vs.length; k++) {
                    vsota += (int) vs[k];
                }
                povp += (int) (vsota / 3);
                st++;
            }
        }
        povp = povp / st;
        povp = (float) ((float) Math.round(povp * 100.0) / 100.0);
        return povp;
    }

    static Slika branjet(String dat) throws Exception {
        FileInputStream fis = null;
        File fileEntry = new File(dat);
        String filename = fileEntry.getName();
        String extension = filename.substring(filename.lastIndexOf(".") + 1, filename.length());
        int visina = 0;
        int sirina = 0;
        Piksel[] dada;
        fis = new FileInputStream(fileEntry);
        DataInputStream dis = new DataInputStream(fis);
        StringBuffer inputline = new StringBuffer();
        if (extension.equalsIgnoreCase("p2t")) {
            String v = dis.readLine();
            inputline.append(v);
            String[] vrstica = v.split(" ");
            if (vrstica[0].equalsIgnoreCase("p2t")) {
                sirina = Integer.parseInt(vrstica[1]);
                visina = Integer.parseInt(vrstica[3]);
                if (visina <= 0 || sirina <= 0 || visina > Integer.MAX_VALUE || sirina > Integer.MAX_VALUE) {
                    throw new Napakapodpis("P2T", "napaka pri velikosti slike.");
                }
            } else {
                throw new Napakapodpis("P2T", "napaka pri podpisu slike.");
            }
            Slika x = new Slika(sirina, visina, dat);
            v = dis.readLine();
            inputline.append(v);
            String[] vrst = v.split(" ");
            Piksel a;
            int r, g, b;
            dada = new Piksel[sirina * visina];
            int st = 0;
            for (int j = 0; j < vrst.length; j = j + 3) {
                r = Integer.parseInt(vrst[j]);
                g = Integer.parseInt(vrst[j + 1]);
                b = Integer.parseInt(vrst[j + 2]);
                a = new Piksel(r, g, b);
                dada[st] = a;
                st++;
            }
            st = 0;
            for (int j = 0; j < sirina; j++) {
                for (int k = 0; k < visina; k++) {
                    x.filaj(j, k, dada[st]);
                    st++;
                }
            }
            return x;
        }

        return new Slika(0, 0, dat);
    }

    static Slika branjeb(String dat) throws Exception {
        FileInputStream fis = null;
        File fileEntry = new File(dat);
        String filename = fileEntry.getName();
        String extension = filename.substring(filename.lastIndexOf(".") + 1, filename.length());
        int visina = 0;
        int sirina = 0;
        Piksel[] dada;
        fis = new FileInputStream(fileEntry);
        DataInputStream dis = new DataInputStream(fis);
        StringBuffer inputline = new StringBuffer();
        if (extension.equalsIgnoreCase("p2b")) {
            int[] podpis = new int[3];
            String str;
            char ch;
            String str2 = "";
            for (int i = 0; i < podpis.length; i++) {
                str = Integer.toHexString(dis.readByte());
                podpis[i] = Integer.valueOf(str, 16);
                ch = (char) podpis[i];
                str2 += ch;
            }
            if (str2.equalsIgnoreCase("p2b")) {
                sirina = dis.readInt();
                visina = dis.readInt();
                if (visina <= 0 || sirina <= 0 || visina > Integer.MAX_VALUE || sirina > Integer.MAX_VALUE) {
                    throw new Napakapodpis("P2T", "napaka pri velikosti slike.");
                }
            } else {
                throw new Napakapodpis("P2T", "napaka pri podpisu slike.");
            }
            Slika x = new Slika(sirina, visina, dat);
            Piksel a;
            int r, g, b;
            dada = new Piksel[sirina * visina];
            int st = 0;
            while (dis.available() > 0) {
                r = (char) dis.read();
                g = (char) dis.read();
                b = (char) dis.read();
                a = new Piksel(r, g, b);
                dada[st] = a;
                st++;
            }
            st = 0;
            for (int j = 0; j < sirina; j++) {
                for (int k = 0; k < visina; k++) {
                    x.filaj(j, k, dada[st]);
                    st++;
                }
            }
            return x;
        }

        return new Slika(0, 0, dat);
    }

    String getIme() {
        return this.imedat;
    }

    int getSirina() {
        return this.sirina;
    }

    int getVisina() {
        return this.visina;
    }

    Piksel getPiksel(int x, int y) {
        Piksel pix = this.piksli[y][x];
        return pix;
    }

}

class Izrisi {

    String opis;
    StringBuilder prviTrije = new StringBuilder("Prvi trije piksli:");
    StringBuilder zadnjiTrije = new StringBuilder("Zadnji trije piksli:");

    public Izrisi(Slika s) {
        int[] rgb;
        String ime = s.getIme();
        int sirina = s.getSirina();
        int visina = s.getVisina();
        opis = String.format("Slika %s, velikosti %d x %d", ime, sirina, visina);
        if (sirina >= 3) {
            for (int i = 0; i < 3; i++) {
                rgb = s.getPiksel(0, i).getKomponente();
                prviTrije.append(String.format(" (%d,%d,%d)", rgb[0], rgb[1], rgb[2]));
                rgb = s.getPiksel(sirina - 1, visina - 3 + i).getKomponente();
                zadnjiTrije.append(String.format(" (%d,%d,%d)", rgb[0], rgb[1], rgb[2]));
            }
        }
    }

    public void prikazi() {
        System.out.printf("%s\n%s\n%s\n", opis, prviTrije.toString(), zadnjiTrije.toString());
    }
}

public class kiki {

    public static void main(String[] args) {
        try {
            Slika a;
            File fileEntry = new File(args[1]);
            String filename = fileEntry.getName();
            String extension = filename.substring(filename.lastIndexOf(".") + 1, filename.length());
            //a=new Slika("C:\\Users\\kikis\\Documents\\NetBeansProjects\\DomačeNaloge\\src\\domačenaloge\\test.p2b",2);
            //new Izrisi(a).prikazi();
            if (extension.equalsIgnoreCase("p2t") || extension.equalsIgnoreCase("p2b")) {
                switch (args[0]) {
                    case "1":
                        a = new Slika(args[1], 1);
                        new Izrisi(a).prikazi();
                        break;
                    case "2":
                        a = new Slika(args[1], 2);
                        new Izrisi(a).prikazi();
                        break;
                    case "4":
                        if (extension.equalsIgnoreCase("p2t")) {
                            a = new Slika(args[1], 1);
                            System.out.println(a.povprecje());
                        } else if (extension.equalsIgnoreCase("p2b")) {
                            a = new Slika(args[1], 2);
                            System.out.println(a.povprecje());
                        }
                        break;
                }

            } else {
                throw new NapakaIme("Datoteka ni v formatu P2T/P2B: napaka v imenu datoteke.");
            }
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
    }
}
