package V_04;

public class V_04 {

    public static boolean vrednost(long crka, int index) {
        return ((crka & 1l << 63 - index) == 1l << 63 - index);
    }

    public static void izpisi(long crka) {      
        int index = 0;
        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 8; j++) {
                if (vrednost(crka, index)) {
                    System.out.print("*");
                } else {
                    System.out.print(" ");
                }
                index++;
            }
            System.out.println();
        }
    }

    public static String fix(String crka, int dolzina) {
        String rez = "";
        for (int i = 0; i < dolzina - crka.length(); i++) {
            rez += "0";
        }
        return rez += crka;
    }

    public static void izpisi(long crke[]) {
        int index = 0;
        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < crke.length; j++) {
                index = i * 8;        
                for (int k = 0; k < 8; k++) {
                    if (vrednost(crke[j], index)) {
                        System.out.print("*");
                    } else {
                        System.out.print(" ");
                    }
                    index++;
                }
            }
            System.out.println();
        }
    }

    
    public static long getCrko(int[] vrstice) {
        long vrednost = 0;
        for (int i = 0; i < vrstice.length; i++) {
            vrednost = (vrednost << 8) | (long)vrstice[i];
        }
        //System.out.println(fix(Long.toBinaryString(vrednost),64));
        return vrednost;
    }
    
    public static long getIme(String crka) {

        crka = crka.replace(' ', '0');
        crka = crka.replace('+', '1');
        return Long.parseUnsignedLong(crka, 2);
    }

    public static void main(String[] args) {
        
        //izpisi(71917410474557695l);
        
        
        /*
        izpisi(new long[]{
            4821103401091611672l, 0, 144680345680364600l, 1739555224076567106l,
            -9114862049243683816l, 1739555224076567106l, 0, 4821103401091611672l
        });*/
        
        
        //long crkaO = getCrko(new int[]{60, 66, 129, 129, 129, 129, 66, 60});
        //System.out.println(crkaO);
        
        izpisi(new long[]{
            144680345680364600l,
            0,
            1739555224076567106l,
            0,
            getCrko(new int[]{34,36,40,48,48,40,36,34}),
            0,
            1739555224076567106l,
            
        });
        
        //izpisi(new long[]{n, 0, e, 0, j, 0, c});
    }
}
