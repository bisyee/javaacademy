public class V_01{
	public static void main(String[] args) {
		pravokotnik(5,3,7);
		System.out.println();
		trikotnik(3,5);
		System.out.println();
		okvir(3,5,5);
		System.out.println();

		trikotnik(1,10);
		okvir(5,10,11);
		System.out.println();

		dvaPravokotnika(5,15,3,6);
		System.out.println();

		trikotnik(1,10);
		pravokotnik(1,10,19);
		dvaPravokotnika(4,6,7,3);
		System.out.println();

		X(6);
	}

	static void pravokotnik(int odmik, int visina, int sirina){
		for(int i = 0;i<visina;i++){
			for(int k=0;k<odmik;k++){
				System.out.printf(" ");
			}
			for(int j = 0; j<sirina;j++){
				System.out.printf("*");
			}
			System.out.println();
		}
	}

	static void trikotnik(int odmik, int visina){
	     for (int i = 0; i < visina; i++){
			for (int j = 0; j < odmik + visina - i - 1; j++) {
				System.out.printf(" ");
			}
			for (int k = 0 ; k <= i*2 ; k++) {
				System.out.printf("*");
			}
			System.out.println();
		}
	}

	static void okvir(int odmik, int visina, int sirina) {
		for(int i = 0;i<visina;i++){
			for(int j = 0;j<odmik;j++){
				System.out.printf(" ");
			}
			for(int k = 0 ;k<sirina;k++){
				if(i == 0 || i == visina-1){
					System.out.print("*");
				}
				else{
					if(k == 0 || k == sirina-1){
						System.out.print("*");
					}
					else{
						System.out.printf(" ");
					}
				}
			}
			System.out.println();
		}
	}

	static void dvaPravokotnika(int odmik, int razmik, int visina, int sirina){
		for(int i = 0;i<visina;i++){
			for(int o = 0;o<odmik;o++){
				System.out.printf(" ");
			}
			for(int j = 0;j<sirina;j++){
				System.out.printf("*");
			}
			for(int r = 0;r<razmik;r++){
				System.out.printf(" ");
			}
			for(int j = 0;j<sirina;j++){
				System.out.printf("*");
			}
			System.out.println();
		}
	}

	static void X(int n){
		for (int i = n; i > 1; i-- ) {
			dvaPravokotnika(4*(n-i),4*(i*2-3),4,4);
		} 
		pravokotnik(4*(n-1), 4, 4);
		for (int i = 0; i < n-1; i++) {
			dvaPravokotnika(4*(n-2-i),4*(i*2+1),4,4);
		}
	}

}