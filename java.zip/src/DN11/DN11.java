//package DN11;

import java.util.*;
import java.io.File;
import java.util.Map.Entry;

/**
 *
 * @author jaka
 */
public class DN11 {

    public static void main(String[] args) throws Exception {
        TreeMap<String, Integer> besede = preberi(args[0]);
        if (args[1].equals("1")) {
            izpis(besede);
        } else if (args[1].equals("2")) {
            SortedSet<Par> sortedBesede = sort(besede);
            for (Par p : sortedBesede) {
                System.out.printf("%-3d %s\n", p.val, p.key);
            }
        }
    }

    static SortedSet sort(TreeMap<String, Integer> tabela) {
        SortedSet<Par> sortedTab = new TreeSet<Par>();
        for (Entry<String, Integer> entry : tabela.entrySet()) {
            sortedTab.add(new Par(entry.getKey(), entry.getValue()));
        }
        return sortedTab;
    }

    public static void izpis(Map<String, Integer> besede) {
        for (String beseda : besede.keySet()) {
            System.out.printf("%-3d   %s\n", besede.get(beseda), beseda);
        }
    }

    public static TreeMap<String, Integer> preberi(String imeDatoteke) throws Exception {
        TreeMap<String, Integer> besede = new TreeMap();

        Scanner sc = new Scanner(new File(imeDatoteke));
        while (sc.hasNext()) {
            //String beseda = sc.next().replaceAll("[^A-Za-z0-9]", "").trim();
            String beseda = sc.next().replaceAll("[\\,\\.\\:\\;\\(\\)\\-]", "").trim();

            if (!besede.containsKey(beseda)) {
                besede.put(beseda, 1);
            } else {
                besede.put(beseda, besede.get(beseda) + 1);
            }
        }
        return besede;
    }
}

class Par implements Comparable<Par> {

    int val;
    String key;

    Par(String key, int val) {
        this.key = key;
        this.val = val;
    }

    @Override
    public int compareTo(Par k) {
        if (this.val > k.val) {
            return -1;
        } else if (this.val < k.val) {
            return 1;
        } else {
            return this.key.compareTo(k.key);
        }
    }
}
