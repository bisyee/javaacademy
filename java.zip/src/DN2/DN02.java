public class DN02 {
	public static void main(String [] args){
		if(args.length != 0){
			pravokotnik(Integer.parseInt(args[0]),Integer.parseInt(args[1]));
		}
		else{
			for(int i=1;i<6;i++){
				for(int j=1;j<6;j++){
					pravokotnik(i,j);
					System.out.print("\n");
				}
			}
		}
	}
	
	static void pravokotnik(int a, int b){
		String niz1 = "a = "+Integer.toString(a)+" , b = "+Integer.toString(b)+"    ";

		for(int i=0;i<a;i++){
			if(i == 0){
				System.out.printf(niz1);
			}
			else{
				for(int  k = 0;k <niz1.length();k++){
					System.out.printf(" ");
				}
			}
			for(int j=0;j<b;j++){
				System.out.printf("X");	
			}
			System.out.println();
		}
	}
}