package V_03;

import java.util.Random;

/**
 *
 * @author jakacenta
 */
public class Tarok {

    static char pik = '\u2660'; // ♠Ï
    static char kriz = '\u2663'; // ♣
    static char srce = '\u2665'; // ♥
    static char karo = '\u2666'; // ♦

    static char barve[] = {srce, karo, kriz, pik};
    static String prazneRdece[] = {"1", "2", "3", "4"};
    static String prazneCrne[] = {"7", "8", "9", "10"};

    static String figure[] = {"Fant", "Kaval", "Dama", "Kralj"};

    static String taroki[] = {
        "I", "II", "III", "IIII", "V", "VI", "VII",
        "VIII", "IX", "X", "XI", "XII", "XIII", "XIV",
        "XV", "XVI", "XVII", "XVIII", "XIX", "XX",
        "XXI", "SKIS"
    };

    public static void main(String[] args) {

        /*String[] karte;
        karte = ustvariKarte();
        izpisi(karte);
        System.out.println();
        premesajKarte(karte, 1);
        izpisi(karte);
        System.out.println(preprostoStetje(karte));*/
        String karte[] = ustvariKarte();
        premesajKarte(karte, 200);

        System.out.println("Prvi kup kart:");
        int kupcek1 = natancnoStetje(karte, true, 0, 25);

        System.out.println("Drugi kup kart:");
        int kupcek2 = natancnoStetje(karte, true, 25, 54);

        System.out.println("Natancno stetje 1. kupa kart: " + kupcek1);
        System.out.println("Natancno stetje 2. kupa kart: " + kupcek2);

    }

    public static String[] ustvariKarte() {
        int index = 0;
        String[] karte = new String[54];
        for (int i = 0; i < barve.length; i++) {
            for (int j = 0; j < 4; j++) {
                if (i < 2) {
                    karte[index++] = String.format("%c%s", barve[i], prazneRdece[j]);
                } else {
                    karte[index++] = String.format("%c%s", barve[i], prazneCrne[j]);
                }
            }
            for (int j = 0; j < figure.length; j++) {
                karte[index++] = String.format("%c%s", barve[i], figure[j]);
            }
        }
        for (int i = 0; i < taroki.length; i++) {
            karte[index++] = taroki[i];
        }
        return karte;
    }

    public static void izpisi(String karte[]) {
        for (int i = 0; i < 54; i++) {
            if (i % 8 == 0) {
                System.out.println();
            }
            System.out.printf("%s ", karte[i]);
        }
    }

    public static void premesajKarte(String karte[], int koliko) {
        Random rand = new Random();
        for (int i = 0; i < koliko; i++) {
            int prva = rand.nextInt(karte.length);
            int druga = rand.nextInt(karte.length);

            String save = karte[prva];
            karte[prva] = karte[druga];
            karte[druga] = save;
        }
    }

    public static int vrednost(String karta) {
        if (karta.equals("SKIS") || karta.equals("I") || karta.equals("XXI") || karta.substring(1).equals("Kralj")) {
            return 5;
        }
        if (karta.substring(1).equals("Dama")) {
            return 4;
        }
        if (karta.substring(1).equals("Kaval")) {
            return 3;
        }
        if (karta.substring(1).equals("Fant")) {
            return 2;
        }
        return 1;
    }

    public static int preprostoStetje(String karte[]) {
        int sestevek = 0;
        for (int i = 0; i < karte.length; i++) {
            sestevek += vrednost(karte[i]);
        }
        return sestevek;
    }

    static int natancnoStetje(String karte[], boolean izpis, int z, int k) {
        int sum = 0;
        for (int i = z; i < k; i += 3) {
            int tmp = 0;
            if ((k - i) >= 3) {
                tmp += vrednost(karte[i]);
                tmp += vrednost(karte[i + 1]);
                tmp += vrednost(karte[i + 2]);
                tmp -= 2;
                if (izpis) {
                    System.out.printf(karte[i] + " " + karte[i + 1] + " " + karte[i + 2] + " " + tmp + "\n");
                }
                sum += tmp;
            } else if ((k - i) == 2) {
                tmp += vrednost(karte[i]);
                tmp += vrednost(karte[i + 1]);
                tmp -= 1;
                if (izpis) {
                    System.out.printf(karte[i] + " " + karte[i + 1] + " " + tmp + "\n");
                }
                sum += tmp;
            } else {
                tmp += vrednost(karte[i]);
                tmp -= 1;
                if (izpis) {
                    System.out.printf(karte[i] + " " + tmp + "\n");
                }
                sum += tmp;
            }
        }

        return sum;
    }

}
