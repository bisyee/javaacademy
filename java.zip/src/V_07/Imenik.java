package V_07;

/**
 *
 * @author jakacenta
 */

import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;

class Oseba{
    String ime;
    String priimek;
    String naslov;
    String mesto;
    String posta;
    String telefon;
    
    public Oseba(String ime, String priimek, String naslov, String mesto, String posta, String telefon) {
        this.ime = ime;
        this.priimek = priimek;
        this.naslov = naslov;
        this.mesto = mesto;
        this.posta = posta;
        this.telefon = telefon;
        
    }
}

public class Imenik {
    
    static Oseba[] imenik;
    
    static Oseba[] preberiOsebe(String vir) throws FileNotFoundException {
        Oseba[] osebe = new Oseba[100];
        Scanner scan = new Scanner(new File(vir));
        int i = 0;
        while (scan.hasNextLine()) {
            String[] atr = scan.nextLine().split(", ");
            osebe[i] = new Oseba(atr[0],atr[1],atr[2],atr[3],atr[4],atr[5]);
            i++;
        }
        return osebe;
    }
    
    static Oseba isciOseboPoImenu(String ime){
        for (int i = 0; i < imenik.length; i++) {
            if(imenik[i] != null  && imenik[i].ime.equals(ime)){
                return imenik[i];
            }
        }
        return null;
    }
    
    static void isciOsebePoPosti(String posta){
        int NumOfPeople = 0;
        for (int i = 0; i < imenik.length; i++) {
            if(imenik[i] != null && imenik[i].mesto.equals(posta)){
                NumOfPeople++;
            }

        }
        System.out.println(NumOfPeople);
    }
    
    public static void main(String[] args) throws Exception {
        imenik = preberiOsebe("imenik.txt");       
        isciOsebePoPosti("1000");
    }
    
}
