import java.util.*;

public class DN03{
	public static void main(String[] args) {
		Locale.setDefault(Locale.ENGLISH);
		int operation = Integer.parseInt(args[0]);
		float num1 = Float.parseFloat(args[1]);
		float num2 = Float.parseFloat(args[2]);
		switch(operation){
			case 1:
				System.out.printf("%.1f + %.1f = %.1f\n",num1,num2,num2+num1); 
				break;

			case 2:
				System.out.printf("%.1f - %.1f = %.1f\n",num1,num2,num1-num2); 
				break;

			case 3: 
				System.out.printf("%.1f * %.1f = %.1f\n",num1,num2,num2*num1); 
				break;

			case 4: 
				System.out.printf("%.1f / %.1f = %.1f\n",num1,num2,num1/num2); 
				break;

			case 5:
				int min_num = 1;
				float temp_num;
				for(int i = 1;i<args.length;i++){
					temp_num = Float.parseFloat(args[i]);
					if(temp_num < Float.parseFloat(args[min_num])){
						min_num = i;
					}
				}
				System.out.print("Minimum stevil ");
				for(int i = 1;i<args.length;i++){
					System.out.print(args[i]+" ");
				}	
				System.out.println("je "+args[min_num]);
				
					 break;

			default: System.out.print("No record");
		}
		
	}
}