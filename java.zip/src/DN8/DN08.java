//package DN8;

/**
 *
 * @author jaka
 */
import java.util.Scanner;
import java.io.File;

class Planet {

    String ime;
    int r = 0;

    double povrsina() {
        return Math.pow(this.r, 2) * Math.PI * 4;
    }
}

public class DN08 {

    public static void main(String[] args) throws Exception {
        //read file
        Scanner sc = new Scanner(new File(args[0]));
        String line;

        //read other arguments
        String[] PlanetsFromArgs = args[1].split("\\+");

        //create table of planets
        Planet[] planeti = new Planet[9];
        for (int q = 0; q < 9; q++) {
            planeti[q] = new Planet();
        }

        //read name and radius from file
        int i = 0;
        while (sc.hasNext()) {
            line = sc.next();
            if (line.contains(":")) {
                planeti[i].ime = line.split(":")[0];;
                planeti[i].r = Integer.parseInt(line.split(":")[1]);
                i++;
            }
        }

        double AreaSum = 0;
        for (int j = 0; j < PlanetsFromArgs.length; j++) {
            for (int k = 0; k < 9; k++) {
                if (PlanetsFromArgs[j].toLowerCase().equals(planeti[k].ime.toLowerCase())) {
                    AreaSum += planeti[k].povrsina();
                }
            }
        }

        System.out.printf("Povrsina planetov \"%s\" je %3d milijonov km2", args[1],(int) Math.round(AreaSum/1000000));

    }

}
