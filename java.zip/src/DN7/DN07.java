import java.awt.Color;
import java.util.Random;

public class DN07 {

    public static void main(String[] args) {
        Random rand = new Random();
        for (int i = 0; i < Integer.parseInt(args[0]); i++) {
            Color c = new Color(rand.nextInt(256), rand.nextInt(256), rand.nextInt(256));
            narisi(rand.nextFloat(), rand.nextFloat(), c, rand.nextDouble());
        }
    }

    public static void narisi(float x, float y, Color b, double v) {
        StdDraw.setPenRadius(v * 0.01);

        v *= 0.1;
        StdDraw.setPenColor(Color.GREEN);
        StdDraw.line(x, y, x, y - (v * 5));
        

        StdDraw.setPenColor(b);
        StdDraw.filledCircle(x - (v * 1.3), y, v);
        StdDraw.filledCircle(x + (v * 1.3), y, v);
        StdDraw.filledCircle(x, y + (v * 1.3), v);
        StdDraw.filledCircle(x, y - (v * 1.3), v);

        StdDraw.setPenColor(Color.GREEN);
        StdDraw.filledCircle(x, y, v / 1.5);
    }
}
