public class JavaZakon {
	public static void main(String [] args){
		for(int i = 0; i < 10 ; i++){
			System.out.println("Java je zakon!");
			System.out.println("Java je a!");
		}
		
	}
}