public class Obresti {
	public static void main(String [] args){
		double G = 1000;
		System.out.println(G);


		
	}
}