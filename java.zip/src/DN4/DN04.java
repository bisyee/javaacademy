public class DN04 {

    public static void main(String[] args) {
        if(args.length == 3){
            check(args[0], args[1], args[2]);
        }
        else{
            System.out.println("false");
        }
        
    }
    static String[] prva = {"Miha", "Micka", "Tone", "Lojze", "Mojca", "Pepca", "Franci", "Francka"};
    static String[] druga = {"vozi", "seka", "potrebuje", "gleda", "barva", "voha", "lomi", "popravlja"};
    static String[] tretja = {"kolo", "avto", "likalnik", "sonce", "vrtnico", "drevo", "lopato", "sekiro"};

    static void check(String prva_s, String druga_s, String tretja_s) {
        for (String prva1 : prva) {
            if (prva1.equals(prva_s)) {
                for (String druga1 : druga) {
                    if (druga1.equals(druga_s)) {
                        for (String tretja1 : tretja) {
                            if (tretja1.equals(tretja_s)) {
                                System.out.println("true");
                                return;
                            }
                        }
                    }
                }
            }
        }
        System.out.println("false");
    }
}
