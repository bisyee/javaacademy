public class DN01 {
	public static void main (String [] args){
		System.out.println("Moje ime je: Jaka Centa\n"+
						   "Moja vpisna številka: 63160083\n");
		
		System.out.println("**************************************************\n"+
						   "* Izjavljam, da sem prebral vsebino strani       *\n"+
						   "* 'Samostojna izdelava programov' na eUčilnici.  *\n"+
						   "* Vse obveznosti predmeta Programiranje 2 bom    *\n"+
						   "* skladno s temi navodili opravil samostojno.    *\n"+
						   "**************************************************\n");		
	}
}