/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package V_06;

import java.util.*;
import java.io.*;

public class V_06 {

    public static void main(String[] args) throws Exception {
        odkodiraj("pesem.txt", "kodirano.txt");
        kodiraj("pesem.txt", "pomlad pomlad pomlad");

    }

    static void odkodiraj(String kodirnaKnjiga, String koda) throws Exception {
        try {
            Scanner sc_code = new Scanner(new File(koda));
            Scanner sc_key = new Scanner(new File(kodirnaKnjiga));
            String code = "";
            String key = sc_key.nextLine();

            //branje obeh datotek v string. Potem se string splita v tabelo
            
            while (sc_code.hasNext()) {
                code += sc_code.nextLine();
            }
            while (sc_key.hasNext()) {
                key += " " + sc_key.nextLine();
            }
            String[] code_arr = code.split("\\ ");
            String[] key_arr = key.split("\\ ");

            
            /*     
            For zanka gre čez tabelo kodiranih črk in vsak par, s
            pomočjo besed v tabeli kodirne knjige, odkodira ter doda
            stringu odkodirano. Pred tem preveri ali prvo
            kodirano število ne presega števila besed v kodirni knjigi
            in drugo kodirano število ne presega števila črk v ustrezni
            besedi. Hkrati zanka preverja, če se pojavijo ničle in jih
            ustrezno pretvori v velike črke, presledke in nove vrstice.
            */
            
            String odkodirano = "";
            boolean cap = false;
            for (int i = 0; i + 2 <= code_arr.length; i += 2) {
                if (code_arr[i].equals("0")) {
                    if (code_arr[i + 1].equals("0")) {
                        if (code_arr[i + 2].equals("0")) {
                            odkodirano += "\n";
                            i += 3;
                        } else {
                            odkodirano += " ";
                            i += 2;
                        }
                    } else {
                        cap = true;
                        i++;
                    }
                }
                if (Integer.parseInt(code_arr[i]) - 1 > key_arr.length || Integer.parseInt(code_arr[i + 1]) - 1 > key_arr[Integer.parseInt(code_arr[i]) - 1].length()) {
                    odkodirano += "?";
                } else {
                    if (cap) {
                        cap = false;
                        odkodirano += Character.toUpperCase(key_arr[Integer.parseInt(code_arr[i]) - 1].charAt(Integer.parseInt(code_arr[i + 1]) - 1));
                    } else {
                        odkodirano += key_arr[Integer.parseInt(code_arr[i]) - 1].charAt(Integer.parseInt(code_arr[i + 1]) - 1);
                    }
                }
            }
            System.out.println(odkodirano);          
        }
        catch(IOException e)
        {
            System.out.println(e);
        }
    }
    
    static void kodiraj(String kodirnaKnjiga, String niz)throws Exception{
        Scanner sc_key = new Scanner(new File(kodirnaKnjiga));
        String key = " "+sc_key.nextLine();
        while(sc_key.hasNext())
        {
            key += " "+sc_key.nextLine();
        }
        String[] key_arr = key.split(" ");
        
        for (int i = 0; i < key_arr.length; i++) {
            System.out.println(i + " " + key_arr[i]);
        }
        
        for (int i = 0; i < niz.length(); i++) {
            for (int j = 0; j < key_arr.length; j++) {
                for (int k = 0; k < key_arr[j].length(); k++) {
                    if(key_arr[j].charAt(k) == (niz.charAt(i))){
                        System.out.println(j+" "+(k+1));
                    }
                }
            }
        }
    }
}
