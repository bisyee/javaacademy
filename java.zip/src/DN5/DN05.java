import java.util.Random;
import java.util.Locale;

public class DN05 {

    public static void main(String[] args) {
        Locale.setDefault(Locale.US);
        if (args[0].equals("1a")) {
            if (args.length == 2) {
                System.out.println(pip_next(args[1]));
            }
        } else if (args[0].equals("1b")) {
            if (args.length == 3) {
                pip(args[1], Integer.parseInt(args[2]));
            }
        } else if (args[0].equals("2a")) {
            System.out.println(stop1(Integer.parseInt(args[1])));
        } else if (args[0].equals("2b")) {
            System.out.println(stop1_2n(Double.parseDouble(args[1])));
        } else if (args[0].equals("3")) {
            vsota(Integer.parseInt(args[1]), Integer.parseInt(args[2]), Integer.parseInt(args[3]), Integer.parseInt(args[4]));
        }

    }

    public static String pip_next(String s) {
        int i = 0;
        int j;
        String[] str = s.split("");
        String new_str = "";
        String curr;
        int curr_len = 0;
        while (i < str.length) {
            curr = str[i];
            j = i;
            while (j < str.length && curr.equals(str[j])) {
                curr_len++;
                j++;
            }
            i = i + curr_len;
            new_str += curr_len + curr;
            curr_len = 0;
        }
        return new_str;
    }

    public static String pip(String s, int n) {
        String new_str = s;
        System.out.println(s);
        for (int i = 0; i < n - 1; i++) {
            new_str = pip_next(new_str);
            System.out.println(new_str);
        }
        return new_str;
    }

    public static int stop1(int n) {
        int c = 1;
        while (n != 1) {
            if (n % 2 == 0) {
                n = n / 2;
            } else {
                n = 3 * n + 1;
            }
            c++;
        }
        return c;
    }

    public static int stop1_2n(double n) {
        return (int) (Math.log(n)/Math.log(2))+1;
    }

    private static double round(double value, int precision) {
        int scale = (int) Math.pow(10, precision);
        System.out.println(scale);
        return (double) Math.round(value * scale) / scale;
    }

    public static void vsota(int n, int m, int max, int seed) {
        Random rand = new Random();
        rand.setSeed(seed);
        float[][] matrika = new float[n][m];
        String sx = "S(x) = ";
        float temp_sum = 0;

        //napolni
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < m; j++) {
                matrika[i][j] = (float) (-max + (max + max) * rand.nextFloat());
            }
        }

        //izracuna
        for (int i = 0; i < m; i++) {
            for (int j = 0; j < n; j++) {
                temp_sum += matrika[j][i];
            }

            if (temp_sum > 0 && i != 0) {
                sx += "+";
            }
            sx += String.format("%2.1f", temp_sum);
            if (m - i - 1 > 1) {
                sx += String.format("x^%d", m - i - 1);
            } else if (m - i - 1 == 1) {
                sx += String.format("x");
            }

            temp_sum = 0;
        }

        //izpis
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < m; j++) {
                System.out.printf("%6.2f", matrika[i][j]);
            }
            System.out.println();
        }
        System.out.println(sx);

    }

}
