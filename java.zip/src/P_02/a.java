public class a{
	public static void main(String [] args){
		String niz = "Pusi kurac!";
		//System.out.printf("Niz: %c", niz.charAt(0));
		System.out.printf("%c",niz.charAt(niz.length()-2));
		System.out.println(niz.replaceAll("!", " Kovac"));

		int stbes = 1;

		for(int i = 0; i < niz.length(); i++){
			System.out.println(niz.charAt(i));
		}

	}
}
