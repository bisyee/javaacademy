//package DN13;

import java.util.*;
import java.io.*;

public class DN13 {

    public static void main(String[] args) throws Exception {
        try {
            if (!(args[1].endsWith("p2t") || args[1].endsWith("p2b"))) {
                throw new nepravilnaKoncnica();
            }
            TreeMap<String, Double> slike = new TreeMap();
            Slika a = null;
            Slika b = null;
            if (args[0].equals("3") || args[0].equals("2") || args[0].equals("1") || args[0].equals("4") || args[0].equals("5")) {
                if (args[1].endsWith("p2t")) {
                    a = Slika.readTextFile(args[1]);

                } else {
                    a = Slika.readBinFile(args[1]);
                }
                if (args[0].equals("3") || args[0].equals("2") || args[0].equals("1")) {
                    new Izrisi(a).prikazi();
                }
                if (args[0].equals("4")) {
                    a.povprecjePikslov();
                }
                if (args[0].equals("5")) {
                    if (args[1].endsWith("p2t")) {
                        String fileName = args[1].split("\\.")[0] + ".p2b";
                        a.exportToBin(fileName);
                        b = Slika.readBinFile(fileName);

                    } else {
                        String fileName = args[1].split("\\.")[0] + ".p2t";
                        a.exportToBin(fileName);
                        b = Slika.readBinFile(fileName);
                    }
                    new Izrisi(b).prikazi();
                }
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
}

class nepravilnaKoncnica extends Exception {

    @Override
    public String getMessage() {
        return "Datoteka ni v formatu P2T/P2B: napaka v imenu datoteke.";
    }
}

class nepravilenFormat extends Exception {

    String msg;

    nepravilenFormat(String msg) {
        this.msg = msg;
    }

    @Override
    public String getMessage() {
        return "Datoteka ni v formatu " + this.msg + ": napaka pri podpisu slike.";
    }
}

class nepravilnaVelikost extends Exception {

    String msg;

    nepravilnaVelikost(String msg) {
        this.msg = msg;
    }

    @Override
    public String getMessage() {
        return "Datoteka ni v formatu" + this.msg + ": napaka pri velikosti slike.";
    }
}

class nepravilnaVrednostPikslov extends Exception {

    String msg;

    nepravilnaVrednostPikslov(String msg) {
        this.msg = msg;
    }

    @Override
    public String getMessage() {
        return "Datoteka ni v formatu" + this.msg + ": napaka pri vrednostih pikslov.";
    }
}

class Piksel {

    private int r;
    private int g;
    private int b;

    public Piksel(int r, int g, int b) {
        this.r = r;
        this.g = g;
        this.b = b;
    }

    public int getR() {
        return r;
    }

    public int getG() {
        return g;
    }

    public int getB() {
        return b;
    }

    public int[] getKomponente() {
        int[] rgb = {this.r, this.g, this.b};
        return rgb;
    }
}

class Slika {

    private int sirina;
    private int visina;
    private String ime;
    private List<Piksel> piksli = new ArrayList<>();

    public Slika() {
    }

    public Slika(int width, int height, String name) {
        this.sirina = width;
        this.visina = height;
        this.ime = name;
    }

    public int getSirina() {
        return sirina;
    }

    public int getVisina() {
        return visina;
    }

    public String getIme() {
        return ime;
    }

    public Piksel getPiksel(int x, int y) {
        return this.piksli.get((y * this.sirina) + (x));
    }

    public void povprecjePikslov() {
        double povprecje = 0;
        for (Piksel p : this.piksli) {
            povprecje += ((p.getR() + p.getG() + p.getB()) / 3);
        }
        System.out.printf("%.2f", povprecje / (this.sirina * this.visina));
    }

    public double povprecjePikslovReturn() {
        double povprecje = 0;
        for (Piksel p : this.piksli) {
            povprecje += ((p.getR() + p.getG() + p.getB()) / 3);
        }
        return (povprecje / (this.sirina * this.visina));
    }

    public static Slika readTextFile(String fileName) throws Exception {
        Slika slika = null;
        FileInputStream fis = null;
        int content;
        try {
            File file = new File(fileName);
            fis = new FileInputStream(file);
            BufferedInputStream bis = new BufferedInputStream(fis);
            DataInputStream dis = new DataInputStream(bis);

            //branje meta podatkov
            String firstline = "";
            while ((content = dis.read()) != 10) {
                firstline += (char) content;
            }
            String[] metadata = firstline.split(" ");
            slika = new Slika(Integer.parseInt(metadata[1]), Integer.parseInt(metadata[3]), file.getName());

            if (!metadata[0].equals("P2T")) {
                throw new nepravilenFormat("P2T");
            }
            if (metadata.length != 4 || Long.parseLong(metadata[1]) <= 0 || Long.parseLong(metadata[1]) > Integer.MAX_VALUE || Long.parseLong(metadata[3]) <= 0 || Long.parseLong(metadata[3]) > Integer.MAX_VALUE) {
                throw new nepravilnaVelikost("P2T");
            }

            //branje podatkov
            String piksel = "";
            int n = 0;
            int space = 0;
            while ((content = dis.read()) != -1) {
                piksel += (char) content;
                if (content == 32) {
                    space++;
                    if (space == 3) {
                        String[] rgb = piksel.split(" ");
                        int r = Integer.parseInt(rgb[0]);
                        int g = Integer.parseInt(rgb[1]);
                        int b = Integer.parseInt(rgb[2]);
                        if (r < 0 || r > 255 || g < 0 || g > 255 || b < 0 || b > 255) {
                            throw new nepravilnaVrednostPikslov("P2T");
                        }
                        slika.piksli.add(new Piksel(r, g, b));
                        n++;
                        space = 0;
                        piksel = "";
                    }
                }
            }
            if (Integer.parseInt(metadata[1]) * Integer.parseInt(metadata[3]) != n) {
                throw new nepravilnaVrednostPikslov("P2T");
            }
        } catch (FileNotFoundException ex) {
            System.out.println("Datoteka ne obstaja!");
        } catch (IOException ex) {
            System.out.println("Napaka pri zapisu podatkov!");
        } finally {
            try {
                if (fis != null) {
                    fis.close();
                }
            } catch (IOException ioe) {
                System.out.println("Napaka pri zapisanju datoteke: " + ioe);
            }
        }
        return slika;
    }

    public static Slika readBinFile(String fileName) throws Exception {
        Slika slika = null;
        FileInputStream fis = null;
        int content;
        String format = "";
        try {
            File file = new File(fileName);
            fis = new FileInputStream(file);
            BufferedInputStream bis = new BufferedInputStream(fis);
            DataInputStream dis = new DataInputStream(bis);

            //branje metapodatkov
            format += (char) dis.read();
            format += (char) dis.read();
            format += (char) dis.read();

            if (!format.equals("P2B")) {
                throw new nepravilenFormat("P2B");
            }

            int sirina = dis.readInt();
            int visina = dis.readInt();

            slika = new Slika(sirina, visina, file.getName());

            if (sirina <= 0 || sirina > Integer.MAX_VALUE || visina <= 0 || visina > Integer.MAX_VALUE) {
                throw new nepravilnaVelikost("P2B");
            }

            //branje podatkov
            int n = 0;
            while ((content = dis.read()) != -1) {
                int r = content;
                int g = dis.read();
                int b = dis.read();

                if (r < 0 || r > 255 || g < 0 || g > 255 || b < 0 || b > 255) {
                    throw new nepravilnaVrednostPikslov("P2B");
                }
                slika.piksli.add(new Piksel(r, g, b));
                n++;
            }
            if (sirina * visina != n) {
                throw new nepravilnaVrednostPikslov("P2B");
            }

        } catch (FileNotFoundException ex) {
            System.out.println("Datoteka ne obstaja!");
        } catch (IOException ex) {
            System.out.println("Napaka pri zapisu podatkov!");
        } finally {
            try {
                if (fis != null) {
                    fis.close();
                }
            } catch (IOException ioe) {
                System.out.println("Napaka pri zapisanju datoteke: " + ioe);
            }
        }
        return slika;
    }

    public void exportToText(String fileName) {
        FileOutputStream fos = null;
        try {
            File file = new File(fileName);
            fos = new FileOutputStream(file);
            DataOutputStream dos = new DataOutputStream(fos);
            dos.writeBytes("P2T " + this.sirina + " x " + this.visina + "\n");
            for (Piksel p : this.piksli) {
                dos.writeBytes(p.getR() + " " + p.getG() + " " + p.getB() + " ");
            }
        } catch (Exception ex) {
            System.out.println("Napaka: " + ex.toString());
        } finally {
            try {
                fos.close();
            } catch (IOException ex) {
                System.out.println("Napaka: " + ex.toString());
            }
        }
    }

    public void exportToBin(String fileName) {
        FileOutputStream fos = null;
        try {
            File file = new File(fileName);
            fos = new FileOutputStream(file);
            DataOutputStream dos = new DataOutputStream(fos);
            dos.writeBytes("P2B");
            dos.writeInt((int) this.sirina);
            dos.writeInt((int) this.visina);
            for (Piksel p : this.piksli) {
                dos.write(p.getR());
                dos.write(p.getG());
                dos.write(p.getB());
            }
        } catch (Exception ex) {
            System.out.println("Napaka: " + ex.toString());
        } finally {
            try {
                fos.close();
            } catch (IOException ex) {
                System.out.println("Napaka: " + ex.toString());
            }
        }
    }
}
