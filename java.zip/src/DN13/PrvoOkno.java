/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DN13;

/**
 *
 * @author jaka
 */
import javax.swing.*;

/**
 *
 * @author tomaz
 */
public class PrvoOkno {

    public static void main(String[] args) {
        JFrame okno = new JFrame();
        okno.setSize(300, 300);
        okno.setLocation(500, 500);
        okno.setTitle("Prvo okno");
        okno.setResizable(false);
        okno.setAlwaysOnTop(true);

        // kaj naj java naredi, če uporabnik v tem oknu pritisne x (close)
        okno.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        okno.setVisible(true);

        JDialog dialog = new JDialog(okno, true);
        dialog.setBounds(100, 100, 100, 100);
        dialog.setVisible(true);
    }

}
