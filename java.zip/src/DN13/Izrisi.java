package DN13;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.util.Arrays;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class Izrisi extends JFrame {

    public Izrisi(Slika s) {
        // ustvarimo platno, na katerem bo prikazana slika
        JPanel platno = new Platno(s);
        // ustvarimo novo okno z naslovom, ki vključuje ime slike
        setTitle("Slika: " + s.getIme());
        // če okno zapremo (klik na x), se program konča
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        // v okno postavimo objekt platno, in sicer v središče (uporabimo robno razvrščanje)
        setLayout(new BorderLayout());
        getContentPane().add(platno, BorderLayout.CENTER);
        // poskrbimo za preračun ustrezne velikosti okna glede na njegove komponente
        pack();
    }

    public void prikazi() {
        this.setVisible(true);
    }
}

class Platno extends JPanel {

    BufferedImage img = null;

    public Platno(Slika s) {
        int sirina = s.getSirina();
        int visina = s.getVisina();
        // nastavimo privzeto velikost platna
        setPreferredSize(new Dimension(sirina, visina));
        img = new BufferedImage(sirina, visina, BufferedImage.TYPE_INT_RGB);
        // v img zapišemo ustrezne vrednosti pikslov iz tabele
        int n = 1;
        for (int i = 0; i < sirina; i++) {
            for (int j = 0; j < visina; j++) {
                int[] rgb = s.getPiksel(i, j).getKomponente();
                //System.out.println(n + " " + Arrays.toString(rgb));
                int piksel = 0xff000000; // alfa
                for (int k = 0; k < 3; k++) {
                    piksel = piksel << 8;
                    piksel += rgb[k];
                }
                img.setRGB(i, j, piksel);
                n++;
            }
        }
    }

    @Override
    public void paintComponent(Graphics g) {
        // izriši sliko
        super.paintComponent(g);
        g.drawImage(img, 0, 0, this);
    }
}
