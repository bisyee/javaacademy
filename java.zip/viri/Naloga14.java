/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
//package izpit;

import java.io.*;
import java.io.FileInputStream;

/**
 *
 * @author jc9152
 */

class KalkulatorException extends Exception{
    String msg="";
    
    KalkulatorException(String msg){
        this.msg=msg;
    }
            
    @Override
    public String getMessage(){
        return msg;
    }
}

public class Naloga14 {
    public static void main(String[] args) throws Exception {
        FileInputStream fis = new FileInputStream(new File(args[0]));
        DataInputStream dis = new DataInputStream(fis);
        
        while(dis.read() != -1){
            
        }
    }
    
    
}
