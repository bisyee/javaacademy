import java.util.ArrayList;
import java.util.Arrays;

public class Seminar {
    public static void main(String[] args) {
        String[][] startMatrix = Utilities.readFromFile("data\\primer1_zacetna.txt");
        String[][] endMatrix = Utilities.readFromFile("data\\primer1_koncna.txt");

        Node startNode = new Node(new BoxMatrix(startMatrix), null);
        Node endNode = new Node(new BoxMatrix(endMatrix), null);

        ArrayList<int[]> path = Algorithms.aStar(startNode, endNode);

        for (int i = path.size() - 1; i >= 0; i--) {
            System.out.println(Arrays.toString(path.get(i)));
        }

        System.out.println(Utilities.compareStates(startNode, endNode, path));
    }
}
