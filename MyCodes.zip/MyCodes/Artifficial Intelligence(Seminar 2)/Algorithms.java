import java.util.*;

public class Algorithms {
    public static ArrayList<int[]> BFS(Node startNode, Node endNode) {
        ArrayList<int[]> path = new ArrayList<>();
        Queue<Node> queue = new ArrayDeque<>();
        HashSet<BoxMatrix> alreadyVisited = new HashSet<>();

        queue.add(startNode);
        Node currentState;

        while (!queue.isEmpty()) {
            currentState = queue.remove();

            if(Arrays.deepEquals(currentState.getBoxMatrix().getMatrix(),
                    endNode.getBoxMatrix().getMatrix())) {
                System.out.println(Arrays.deepToString(currentState.getBoxMatrix().getMatrix()));
               path = Node.trackPath(currentState);
               break;
            }
            else {
                alreadyVisited.add(currentState.getBoxMatrix());
                currentState.bindOffspring();
                queue.addAll(currentState.getOffspring());
                queue.removeIf(state -> alreadyVisited.contains(state.getBoxMatrix()));

            }
        }

        return path;
    }

  
    public static ArrayList<int[]> aStar(Node startNode, Node endNode) {
        Stack<Node> stack = new Stack<>();
        stack.push(startNode);
        Node currentNode;
        ArrayList<int[]> path = new ArrayList<>();
        HashSet<BoxMatrix> alreadyVisited = new HashSet<>();

        int iterations = 0;

        while (!stack.isEmpty()){
            currentNode = stack.pop();
            iterations += 1;
            if(Arrays.deepEquals(currentNode.getBoxMatrix().getMatrix(),
                    endNode.getBoxMatrix().getMatrix())) {

                path = Node.trackPath(currentNode);

                System.out.println("A Star: "+ Arrays.deepToString(currentNode.getBoxMatrix().getMatrix()) +
                        " iterations: " + iterations);
            }

            if(!alreadyVisited.contains(currentNode.getBoxMatrix())){
                currentNode.bindOffspring();
                ArrayList<Node> children = currentNode.getOffspring();

                Node bestOne = getBestHeuristic(children,endNode);
                children.remove(bestOne);
                for(int i=0;i<children.size();i++){
                    if(!alreadyVisited.contains(currentNode.getBoxMatrix())){
                        stack.push(children.get(i));
                    }
                }
                stack.push(bestOne);

                alreadyVisited.add(currentNode.getBoxMatrix());
            }
        }
        return  path;
    }

    private static Node getBestHeuristic(ArrayList<Node> options, Node endNode){
        int bestHeuristic = heuristicAlgorithm(options.get(0),endNode);
        int currentHeuristic;
        Node bestState = options.get(0);
        HashSet<BoxMatrix> alreadyVisited = new HashSet<>();


        for(int i = 1;i<options.size();i++){
            if(!alreadyVisited.contains(options.get(i).getBoxMatrix())){
                currentHeuristic = heuristicAlgorithm(options.get(i),endNode);
                if(currentHeuristic > bestHeuristic){
                    bestState = options.get(i);
                    bestHeuristic = currentHeuristic;
                }
            }
        }

        return bestState;
    }

    private static int heuristicAlgorithm(Node compareState, Node endState){
        int score = 0;
        int height;

        for(int i=0;i<endState.getBoxMatrix().getMatrix().length;i++){
            height = whoIsSmaller(compareState,endState,i);
            for(int j=1;j<height;j++){
                if(compareState.getNode(i,j-1).equals(endState.getNode(i,j-1))){
                    //if previous item was correct
                    if(compareState.getNode(i,j).equals(endState.getNode(i,j))){
                        //if this item is correct
                        score += 1;
                    }
                    else{
                        //if only previous is correct
                        score += 0;
                    }
                }
                else{
                    //if previous is wrong
                    score -= 1;
                }
            }
        }

        return score;
    }

    private static int whoIsSmaller(Node compareState, Node endState, int index){ //used for heuristic alg
        if(compareState.getBoxMatrix().getMatrix()[index].size() >
                endState.getBoxMatrix().getMatrix()[index].size()){
            return endState.getBoxMatrix().getMatrix()[index].size();
        }
        else {
            return compareState.getBoxMatrix().getMatrix()[index].size();
        }
    }
}