import java.io.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

public class Utilities {
    static String[][] readFromFile(String pathName) {
        File file = new File(pathName);

        ArrayList<ArrayList<String>> temp = new ArrayList<>();
        try (Scanner sc = new Scanner(file)) {
            while (sc.hasNextLine()) {
                String line = sc.nextLine();
                String[] lineSplit = line.split(",");

                ArrayList<String> level = new ArrayList<>(Arrays.asList(lineSplit));
                temp.add(level);
            }
        } catch (FileNotFoundException e) {
            System.out.println(e.getMessage());
        }

        //System.out.println(temp);
        String[][] result = new String[temp.get(0).size()][temp.size()];
        for (int i = 0; i < temp.size(); i++) {
            for (int j = 0; j < temp.get(i).size(); j++) {
                result[j][i] = temp.get(i).get(j);

            }
        }

        return result;
    }

    static boolean compareStates(Node startState, Node endState, ArrayList<int[]> movements) {
        for (int i = movements.size() - 1; i > -1; i--) {
            try {
                startState.setBoxMatrix(startState.getBoxMatrix().move(movements.get(i)[0],
                        movements.get(i)[1]));
            } catch (Exception e) {
                System.out.println(e.getMessage());
            }

        }
        return Arrays.deepEquals(startState.getBoxMatrix().getMatrix(),
                endState.getBoxMatrix().getMatrix());
    }
}