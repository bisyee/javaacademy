import java.util.ArrayList;

public class Node {
    private BoxMatrix boxMatrix;
    private Node parent;
    private ArrayList<Node> offspring;

    public Node(BoxMatrix positions, Node parent) {
        this.boxMatrix = positions;
        this.parent = parent;
        this.offspring = new ArrayList<>();
    }

    public BoxMatrix getBoxMatrix() {
        return boxMatrix;
    }

    public void setBoxMatrix(BoxMatrix boxes) {
        this.boxMatrix = boxes;
    }

    public ArrayList<Node> getOffspring() {
        return offspring;
    }

    public String getNode(int r, int c){
        return getBoxMatrix().getMatrix()[r].get(c);
    }

    public static ArrayList<int[]> trackPath(Node destination) {
        ArrayList<int[]> path = new ArrayList<>();
        while (destination != null) {
            path.add(destination.getBoxMatrix().getTraversal());
            destination = destination.parent;
        }

        return path;
    }

    public void bindOffspring(){
        for (BoxMatrix matrix: this.boxMatrix.bindOffspring()) {
            this.offspring.add(new Node(matrix, this));
        }
    }
}