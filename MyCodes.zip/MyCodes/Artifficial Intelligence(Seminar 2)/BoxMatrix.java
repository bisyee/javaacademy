import java.util.*;

public class BoxMatrix {
    private Stack<String>[] boxes;
    int rows, maxRows;
    //keep track of movements
    private int[] traversal;

    public BoxMatrix(String[][] matrix) {
        this.boxes = new Stack [matrix.length];
        this.maxRows = matrix[0].length;

        for (int i = 0; i < matrix.length; i++) {
            Stack<String> s = new Stack<>();
            for (int j = matrix[0].length - 1; j >= 0; j--) {
                if(matrix[i][j].matches("'[a-zA-Z]+'")) {
                    s.push(matrix[i][j]);
                }
            }

            this.boxes[i] = s;
        }

        this.traversal = new int[]{0, 0};
    }


    public BoxMatrix(Stack[] boxes, int maxRows, int[] traversal) {
        this.maxRows = maxRows;
        this.boxes = boxes;
        this.traversal = traversal;
    }

    public int[] getTraversal() {
        return traversal;
    }

    public Stack<String>[] getMatrix() {
        return boxes;
    }

    public BoxMatrix move(int p, int r) throws Exception {
        Stack<String>[] path = new Stack[this.boxes.length];
        for (int i = 0; i < this.boxes.length; i++) {
            Stack<String> temp = (Stack<String>) (this.boxes[i]).clone();
            path[i] = (temp);
        }

        if((this.boxes[p]).isEmpty()) {
            throw new Exception("Stack is empty");
        }

        if(this.boxes[r].size() >= maxRows){
            throw  new Exception("Stack is full!");
        }

        String from = path[p].pop();
        path[r].push(from);

        return new BoxMatrix(path, this.maxRows, new int[]{p, r});
    }

    ArrayList<BoxMatrix> bindOffspring() {
        ArrayList<BoxMatrix> children = new ArrayList<>();
        for (int i = 0; i < this.boxes.length; i++) {
            for (int j = 0; j < this.boxes.length; j++) {
                if (i != j) {
                    try {
                        children.add(this.move(i, j));
                    }
                    catch (Exception ignored) {
                    }
                }
            }
        }
        return children;
    }

    public void printMatrix() {
        for(Stack<String> stack : boxes) {
            System.out.println(stack);
        }
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        BoxMatrix boxes = (BoxMatrix) o;
        return rows == boxes.rows && maxRows == boxes.maxRows && Arrays.equals(this.boxes, boxes.boxes);
    }

    @Override
    public int hashCode() {
        int result = Objects.hash(rows, maxRows);
        result = 31 * result + Arrays.hashCode(boxes);
        return result;
    }
}
