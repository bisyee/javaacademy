from random import *


karte = list(range(1, 7)) * 2
shuffle(karte)
peter, pavel = karte[:6], karte[6:]

novi_peter = []
novi_pavel = []

print("Peter v začetku: " + str(peter))
print("Pavel v začetku: " + str(pavel))

for x in  range(0,6):
    if peter[x] > pavel[x]:
        novi_peter.append(peter[x])
        novi_peter.append(pavel[x])
    elif peter[x] < pavel[x]:
        novi_pavel.append(pavel[x])
        novi_pavel.append(peter[x])

print("Peter na koncu: " + str(novi_peter))
print("Pavel na koncu: " + str(novi_pavel))