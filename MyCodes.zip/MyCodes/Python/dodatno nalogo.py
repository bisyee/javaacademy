from random import *


karte = list(range(1, 7)) * 2
shuffle(karte)

peter, pavel = karte[:6], karte[6:]

novi_peter = []
novi_pavel = []

print("Peter v začetku: " + str(peter))
print("Pavel v začetku: " + str(pavel))
while (len(peter) != 0 and len(pavel) != 0):

     if peter[0] > pavel[0]:
         peter.append(peter[0])
         peter.append(pavel[0])
         del peter[0]
         del pavel[0]
     elif peter[0] < pavel[0]:
        pavel.append(pavel[0])
        pavel.append(peter[0])
        del peter[0]
        del pavel[0]
     else:
        del peter[0]
        del pavel[0]

     print("Petar" + str(peter))
     print("Pavel" + str(pavel))

print("Peter na koncu: " + str(peter))
print("Pavel na koncu: " + str(pavel))


