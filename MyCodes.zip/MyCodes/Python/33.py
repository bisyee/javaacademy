from random import *

karte = list(range(1, 7)) * 2
shuffle(karte)
peter, pavel = karte[:6], karte[6:]
print("Peter's cards in the beginning:", peter)
print("Pavel's cards in the beginning:'",pavel)
new_a = []
new_b = []
i=0
while i < 6:
    if peter[i] > pavel[i]:
        new_a.append(peter[i])
        new_a.append(pavel[i])
    else:
        if pavel[i] > peter[i]:
          new_b.append(pavel[i])
          new_a.append(peter[i])

    i+=1
print("Peter's cards at the end",new_a)
print("Pavel's cards at the end",new_b)