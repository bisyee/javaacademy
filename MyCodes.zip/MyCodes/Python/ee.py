from time import time

def menjave(initial_order, swaps):
       d=[]
       for i in range(0, len(swaps)):
        t=swaps[i][0]
        p=swaps[i][1]
        value1= initial_order[t]
        value2=initial_order[p]
        if t == 0:
            d.append(value1)
        elif p== 0:
            d.append(value2)
        initial_order.remove(value1)
        initial_order.remove(value2)
        initial_order.insert(p-1, value1)
        initial_order.insert(t,value2)
        return set(d)

print(menjave(razpored, [(0, 4), (1, 2), (0, 2)]))


def izmenicna_vsota(s):
    if not s:
        return 0
    if s[0] % 2 == 0:
        return s[0] + izmenicna_vsota(s[1:])
    else:
        return -s[0] + izmenicna_vsota(s[1:])

def najblizji_par(s):
    dif=0
    t=0
    j=1
    list=[]
    for i in s:
        while j<len(s):
            if dif > abs(i-s[j]):
             dif= abs(i-s[j])
            if t <= dif:
               dif=t
               list.append([s[j], i])
            j+=1
    return tuple(list[-1])

def pari(s):
    dif=abs(s[0]- s[1])
    counter= 0
    list=[]
    for i in  s:

        for k in s:
             if counter > 0 and abs(i-k) < dif:
                 list.append([i,k])
    return set(list[-1])


class Tasks():
    def __init__(self, task_name, deadline, time):
        self.task_name= " "
        self.deadline= 0
        self.time= 0
        self.opravljena = []

    def dodaj(self, task_name, deadline):
        return self.task_name.time() < self.deadline

    def opravi(self, task_name, time):
        





