xs = ['A', 'B','C', 'D', 'E', 'F', 'G', 'A', 'B']
xp = ['D', 'E', 'F', 'G']
k=1
n=len(xs)
m=len(xp)
while k<=(n-m+1):
    i = 1
    mismatch = 0
    while i<=m and mismatch==0:
        if xp[i] != xs[k+(i-1)]:
            mismatch=1
            print("There is no match at position")
        else:
            i+=1
        break
    if mismatch==0:
        print("There is match at position")
    k+=1
    break







