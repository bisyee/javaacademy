# Tu napiši svoje funkcije
def lahko_sledi(prej,potem):
    if prej[-1:] == potem[0]:
        return True
    else:
        return False

def izberi_besedo(beseda,slovar):

    append.slovar(beseda)
