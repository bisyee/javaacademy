from collections import defaultdict
def statistika(podatki, drzava, n):
    rez=0
    podatkiSplit = podatki.splitlines()
    for i in podatkiSplit:
        splitPod = i.split(":")
        if splitPod[0] == drzava:
            rez=0
            splitElementi=splitPod[1].split(",")
            while n-1 >= 0 and n <= len(splitElementi):
                rez+= int(splitElementi[len(splitElementi)-n])
                n-=1
            while n - len(splitElementi) >= 0 and n>= len(splitElementi):
                rez+= int(splitElementi[len(splitElementi)-n])
                n-=1
    return rez

stiki={"klara" : "kavo", "maria" : "sport", "nika" : "kosarko"}

def stevilo_okuzenih(oseba):

    st.okuzenih=0 #Prajs variable za broj na zaboleni
    endangered_activities= stiki[oseba] #Preku oseba- key primer ak e marija dobivas koj aktivnosti gi praela
    for i in stiki.keys(): # for loop za site osobi
        if  i != oseba: #ako i e marija togas ne vlegvi, odi vo else poso nejze ne trebit da ja brojs
            for j in stiki[i]: #ako ne e marija togas for loop vo aktivnostite od drugata licnost
                for k in endangered_activities: #us eden loop za aktivnostite so gi praela marija
                    if j == k: #ako element od aktivnostite od marija e ednakov so aktivnostite od drugata licnost znacit dek e v karantin
                        st.okuzenih+=1
        else:
            st.okuzenih=st.okuzenih#else e trivijalen dek nez so da stam xD
    return st.okuzenih











def v_karanteno(aktivnosti, okuzeni):
    list = []
    activit=[]
    newlist=[]
    forx = []
    for i in okuzeni:
        activities = aktivnosti.get(i)
        activit.append(activities)
    for i in activit:
        for x in i:
            list.append(x)
    for i in list:
        for x in aktivnosti.values():
            for z in x:
                if z == i:
                    newlist.append(x)
    for key in aktivnosti.keys():
        for x in newlist:
            if aktivnosti[key] == x:
             forx.append(key)
    for z in okuzeni:
        forx.append(z)
    forx=set(forx)
    return forx

def trojke(s, n):
    list=[]
    rez = defaultdict(int)
    for i in range(len(s) - 2):
        trojka = ""
        for j in range(3):
            trojka += s[i + j]
        rez[trojka] += 1

    rez=sorted(rez.items(), key= lambda x:x[1], reverse= True)

    for i in rez:
        list.append(i[0])
    return list


class Oseba:

    def __init__(self):
        self.aktivnosti = {}

    def aktivnost(self, kaj, kdaj):
        self.aktivnosti[kaj] = kdaj

    def vse_aktivnosti(self):
        return set(self.aktivnosti.keys())

    def mozna_okuzba(self, druga_oseba):
        for i in self.aktivnosti.keys():
            if i in druga_oseba.vse_aktivnosti():
                if self.aktivnosti[i] == druga_oseba.aktivnosti[i]:
                    return True
        return False


class VarnaOseba(Oseba):
    def __init__(self, list):
        self.aktivnostiMask = list
        super().__init__()

    def mozna_okuzba(self, druga_oseba):
        for i in self.aktivnostiMask.keys():
            if i not in druga_oseba.aktivnostiMask():
                if i in druga_oseba.super().aktivnosti.keys():
                    if super().aktivnosti[i] == druga_oseba.super().aktivnosti[i]:
                        return True
        return False

