from math import*
from random import*
#Obvezna
def najvecja_potenca(n):
    trenutno=0
    for x in range(n):
        stevilo=2**x
        if stevilo > n:
            break
        else:
            trenutno = stevilo
    return trenutno

def razbij(n):
    seznam=[]
    zbir_v_seznam=0
    stevilo_zdaj=najvecja_potenca(n)
    while True:
        if stevilo_zdaj<1:
            break
        if n - (zbir_v_seznam+stevilo_zdaj) >=0:
            seznam.append(stevilo_zdaj)
            zbir_v_seznam+=stevilo_zdaj
        stevilo_zdaj=stevilo_zdaj//2
    return seznam

def vsebuje(s, x):
    return  x in s

def razlika(s, t):
    seznam=[]
    seznam1=[]
    treta=[]
    for x in s:
        if x in seznam:
            seznam.remove(x)
        else:
            seznam.append(x)
    for y in t:
        if y in seznam1:
            seznam1.remove(y)
        else:
            seznam1.append(y)
    for item in seznam:
        if item not in seznam1:
            treta.append(item)
    for item1 in seznam1:
        if item1 not in seznam:
            treta.append(item1)
    return treta

def razbij_seznam(s):
    nov_seznam = []
    for element in s:
        nov_seznam.append(razbij(element))
    return nov_seznam

def razbij_seznam(s):
    return [razbij(n) for n in s]

def vsota(s):
    vsota=0
    for sekoe in s:
        vsota+=sekoe
    return vsota

def zdruzi_sezname(s):
    zdruzeni=[]
    for sez in s:
        zdruzeni=razlika(sez, zdruzeni)
    return zdruzeni

def poteza_racunalnik(s):
    i=0
    seznam_razbitj = []
    for x in s:
        seznam_razbitj.append(razbij(x))
    elemente_lihokrat=zdruzi_sezname(seznam_razbitj)
    if elemente_lihokrat==[]:
        m = randint(0, len(s) - 1)
        z = randint(1, s[m])
        return m, z
    else:
        for x in seznam_razbitj:
            if vsota(x) >= vsota(razlika(x, elemente_lihokrat)):
                return i, vsota(x) - vsota(razlika(x, elemente_lihokrat))
            else:
                i += 1

import unittest

class TestObvezna(unittest.TestCase):
    def test_najvecja_potenca(self):
        self.assertEqual(najvecja_potenca(20), 16)
        self.assertEqual(najvecja_potenca(16), 16)
        self.assertEqual(najvecja_potenca(5), 4)
        self.assertEqual(najvecja_potenca(2 ** 10000), 2 ** 10000)
        self.assertEqual(najvecja_potenca(1), 1)

    def test_razbij(self):
        self.assertEqual(razbij(22), [16, 4, 2])
        self.assertEqual(razbij(23), [16, 4, 2, 1])
        self.assertEqual(razbij(56), [32, 16, 8])
        self.assertEqual(razbij(2 ** 10000 + 2 ** 5000 + 5), [2 ** 10000, 2 ** 5000, 4, 1])
        self.assertEqual(razbij(1), [1])
        self.assertEqual(razbij(0), [])

    def test_razlika(self):
        self.assertEqual(sorted(razlika([1, 2, 4], [1, 4, 8])), [2, 8])
        self.assertEqual(sorted(razlika([4, 1, 16], [1, 8, 2])), [2, 4, 8, 16])
        self.assertEqual(sorted(razlika([1, 2, 5, 13, 7], [13, 7, 1, 2])), [5])
        self.assertEqual(sorted(razlika([1, 2, 5, 13, 7], [13, 7, 1, 2, 5])), [])
        self.assertEqual(sorted(razlika([1, 2, 5, 13, 7], [])), [1, 2, 5, 7, 13])
        self.assertEqual(sorted(razlika([], [42])), [42])
        self.assertEqual(sorted(razlika([42], [42])), [])
        self.assertEqual(sorted(razlika([], [])), [])

    def test_razbij_seznam(self):
        self.assertEqual(razbij_seznam([22, 56, 7]), [[16, 4, 2], [32, 16, 8], [4, 2, 1]])
        self.assertEqual(razbij_seznam([22]), [[16, 4, 2]])
        self.assertEqual(razbij_seznam([]), [])

    def test_zdruzi_sezname(self):
        self.assertEqual(sorted(zdruzi_sezname([[16, 4, 2], [32, 16, 8], [4, 2, 1]])), [1, 8, 32])
        self.assertEqual(zdruzi_sezname([[1, 2, 3]]), [1, 2, 3])
        self.assertEqual(zdruzi_sezname([]), [])

    def test_vsota(self):
        self.assertEqual(vsota([5, 1, 2, 5]), 13)
        self.assertEqual(vsota([5, 1, 2, 5] + [42] * 100), 4213)
        self.assertEqual(vsota([]), 0)

    def test_poteza_racunalnik(self):
        for s in ([2, 8, 9, 3], [1, 2, 4, 8, 16, 32, 64, 128, 255]):
            poteze = set()
            for i in range(5000):
                vrstica, kovancev = poteza_racunalnik(s)
                self.assertLess(vrstica, len(s), "preveilka številka vrstice")
                self.assertLessEqual(kovancev, s[vrstica], "v tej vrstici ni dovolj kovancev")
                poteze.add((vrstica, kovancev))
            self.assertGreater(len(poteze), 10, "poteze niso videti naključne")
            self.assertEqual(len({v for v, _ in poteze}), len(s), "poteze niso naključne - nekatere vrstice niso nikoli izbrane")

    def test_vsebuje(self):
        self.assertTrue(vsebuje([4, 1, 5, 2, 8], 4))
        self.assertTrue(vsebuje([4, 1, 5, 2, 8], 1))
        self.assertTrue(vsebuje([4, 1, 5, 2, 8], 5))
        self.assertTrue(vsebuje([4, 1, 5, 2, 8], 2))
        self.assertTrue(vsebuje([4, 1, 5, 2, 8], 8))
        self.assertTrue(vsebuje([4], 4))
        self.assertTrue(vsebuje([4, 0, 1], 0))
        self.assertTrue(vsebuje([0], 0))

        self.assertFalse(vsebuje([4, 1, 5, 2, 8], 42))
        self.assertFalse(vsebuje([], 42))
        self.assertFalse(vsebuje([], 0))


class TestDodatna(unittest.TestCase):
    def test_poteza_racunalnik(self):
        from random import randint
        from functools import reduce
        from operator import xor

        for i in range(1000):
            s = [randint(3, 10) for _ in range(randint(3, 10))]
            v, k = poteza_racunalnik(s)
            t = s[:]
            t[v] -= k
            self.assertEqual(
                reduce(xor, s) * reduce(xor, t), 0,
                f"pri {s} je predlagal {(v, k)}, kar ni optimalno")


if __name__ == "__main__":
    unittest.main()


