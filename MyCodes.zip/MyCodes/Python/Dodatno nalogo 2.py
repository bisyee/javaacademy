from math import *
from random import *
kovancev = 127
stava = 1

while kovancev != 128:
    print("Imam " + str(kovancev) + " ; stavil bom " + str(stava))
    rand_num = randint(1, 6)
    if rand_num % 2 == 0:
        print("Zmagal!")
        kovancev += stava
    else:
        print("Izgubil.")
        kovancev -= stava
        stava *= 2
