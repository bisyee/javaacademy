# Napiši funkcijo slovar_besed(besedilo), ki sestavi slovar besed, ki se pojavijo v gornjem besedilu. Vsaki besedi je dodeljen indeks;
# beseda, ki se pojavi prej, ima nižji indeks.
# (Torej: prva beseda ima indeks 0 in vsaka naslednja beseda, ki se še ni pojavila, dobi prvi prosti indeks


def slovar_besed(besedilo):
    list = besedilo.split()
    i = 0
    a = 1
    while i <= len(list) - a:
        j = i + 1
        while j <= len(list) - a:
            if list[j] == list[i]:
                del (list[j])
            else:
                j = j + 1
        i += 1
    list = {list[i]: i for i in range(0, len(list))}

    return list

print(slovar_besed("stavek ki to ni ker stavek ni kar to ni"))


# Napiši funkcijo stisni_besedilo, ki prejme besedilo (v obliki niza) in slovar, ki pove, v katero številko se preslika katera beseda.
# Funkcija naj vrne seznam števil, v katere se preslikajo besede.

def stisni_besedilo(besedilo, slovar):
    beseda = besedilo.split()
    l = []
    for x in beseda:
        l.append(slovar[x])
    return l


# value = slovar[beseda]

# Napiši funkcijo obrni_slovar(slovar), ki prejme slovar, kot ga imamo v prejšnjih nalogah.
# Vrne seznam, v katerem je vsaka beseda na tistem mestu,
# na katerem je vrednost, ki ji pripada v slovarju. Predpostaviti smeš, da med številkami, ki pripadajo besedam, ni "lukenj":
# če neki besedi pripada številka 4, obstajajo tudi besede, ki jim pripadajo številke 0, 1, 2, in 3.
# {"ni": 3, "ker": 4, "kar": 5, "stavek": 0, "ki": 1, "to": 2}
def obrni_slovar(slovar):
    listofvalues = []
    sortedlist = []
    j=0
    for i in slovar:
        listofvalues.append(slovar[i])
    listofvalues.sort()
    for i in listofvalues:
        for word, x in slovar.items():
            if x == i:
                sortedlist.insert(j, word)
                j+=1
    return sortedlist

#Napiši funkcijo raztegni_besedilo(besedilo, slovar), ki prejme besedilo v obliki seznama števil
# (kot ga vrne funkcija stisni_besedilo) in slovar, ki pove, kateri besedi pripada katera številka.
# Funkcija vrne besedilo v obliki niza.

def raztegni_besedilo(besedilo,slovar):
    list=[]
    j=0
    for i in besedilo:
        for word, x in slovar.items():
            if x == i:
                list.insert(j, word)
                j+=1
    liststr = ' '.join([str(x) for x in list])
    return liststr

#Napiši funkcijo razbij_besedilo(besedilo), ki prejme niz in vrne seznam besed in znakov v tem besedilu.
# Vsaka beseda (zaporedje črk) v nizu, postane en element slovarja. Vsak drug znak (vključno s presledki), pa je v seznamu kot posamičen element.
# Glej spodnji zgled.

def razbij_besedilo(besedilo):
    list=[]
    j=0
    a=""
    for i in besedilo:
            if i.isalpha()  == False:
                if a != '':
                    list.insert(j,a)
                j+=1
                list.insert(j,i)
                j+=1
                a = ''
            else:
                a+=i
    return list

print(razbij_besedilo("Stavek - čudna reč, ti stavki!"))