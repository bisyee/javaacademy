word1 = input("Write down a word")
letter

