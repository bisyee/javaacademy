# Napiši funkcijo samoopisno(n), ki vrne True, če je število n samoopisno, in False, če ni.
# (Funkcija naj to v resnici preveri. Ne napišite funkcije, ki v resnici vsebuje seznam samoopisnih števil!)
# Tudi število 3211000 je samoopisno, saj vsebuje 3 ničle, 2 enici, 1 dvojko, 1 trojko, 0 štiric, 0 petic, 0 štestic.
from typing import List


def samoopisno(n):
    lista_s = [int(i) for i in str(n)]
    j = 0
    set = 0
    while j <= len(lista_s) - 1:
        if lista_s[j] == lista_s.count(j):
            set += 1
        j = j + 1
    return set == len(lista_s)


def sum_digits(n): #the sum of the digits of self descriptive number is equal to the numer of the digits
    s = 0
    while n:
        s += n % 10
        n //= 10
    return s



# Napiši funkcijo vsa_samoopisna(d), ki vrne seznam vseh d-mestnih samoopisnih števil. Predpostaviti smeš, da je d največ 7.
# (Funkcija naj preprosto poskusi vsa d-mestna števila tako, da za vsako pokliče funkcijo samoopisno.)
# the digit sum equals the total number of digits, which is equal to the base

def vsa_samoopisna(d):#d number of cipher that the samoopisnostevilo consists
    if d>7:
        print("Enter a number with less than 7 digits")
    s=[]
    j=0
    for x in range(pow(10,(d-1)), (d-1)*pow(10,(d+1))):
        if  samoopisno(x) == True and len(str(x)) == d:
            s.insert(j,x)
            j=j+1

    return s

#Napiši funkcijo pretvori(n, b), ki vrne niz s številom n, zapisanim v številskem sistemu z osnovo b.
from math import*

def pretvori(n,b):
    list=[]
    j=0
    d=0
    p=1
    number=0
    while n >= 1:
        d=int(n%b)

        list.insert(j,d)
        n=int(n/b)

        j=j+1
    for x in list:
        number+= x*p
        p *= 10
    number= str(number)
    return number

#Napiši funkcijo samoopisno_b(n, b), ki vrne True, če je podano število n samoopisno, če ga zapišemo v številskem sistemu z osnovo b.

def samoopisno_b(n,b):
    return samoopisno(pretvori(n,b))


print(samoopisno_b(100, 4))










