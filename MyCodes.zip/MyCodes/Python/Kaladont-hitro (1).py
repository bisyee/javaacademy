def lahko_sledi(prej,potem):
    return True if (prej != potem and prej[-1:] == potem[0]) else False
def ni_ponavljanj(besede):
    return len(besede) == len(set(besede))
def preveri_zaporedje(besede):
    return True if ni_ponavljanj(besede)==True and all(lahko_sledi(besede[p], besede[p+1])!= False for p in range(len(besede)-1)) else False
def mozne_naslednje(beseda,slovar):
    return [ slovar[i] for i in range(len(slovar)) if (beseda[-1:]== slovar[i][0])]