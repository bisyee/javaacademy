def lahko_sledi(prej, potem):

    if prej != potem and prej[-1:] == potem[0]:
        return True
    else:
        return False


# izberi_besedo(beseda, slovar) prejme niz beseda in seznam slovar, ki vsebuje vse možne besede.
# Funkcija vrne besedo iz slovarja, ki sme slediti podani besedi.
# Ker bo običajno na voljo več kandidatov, naj vrne najdaljšo besedo.
# Če je enako dolgih besed več, naj vrne tisto, ki je prej po abecedi.
def izberi_besedo(beseda, slovar):
    e = len(slovar)  # Getting the number of elements in the list
    i = 0
    number = 1
    listofl = []
    largestWord = ""

    while i <=e-1:
        if lahko_sledi(beseda, slovar[i]) is True:
                if len(largestWord) == len(slovar[i]):
                        listofl.insert(number,largestWord)
                        number += 1 # Incrementing the number of largest words found in the list
                        listofl.insert(number, slovar[i])# Writing the largest words in the list

                        print(listofl)

                elif  len(largestWord) < len(slovar[i]):
                    largestWord = slovar[i]
        i += 1
        if number > 1:
           listofl.sort()  # Sorting the list of largest number by alphabetical order
           print(listofl)
           largestWord = listofl[0]

    return largestWord


#ni_ponavljanj(besede) prejme seznam besed in vrne True, če se nobena beseda ne ponovi, ter False, če se.
def ni_ponavljanj(besede):


    s = len(besede) - 1
    i = 0
    j = 0
    while i < s:
        j = i + 1
        while j < s:
            if besede[j] == besede[i]:
                return False
            j += 1
        i += 1
    return True
#preveri_zaporedje(besede) prejme zaporedje besed, izrečenih v igri in vrne True, če je zaporedje legalno.
# Zaporedje je legalno, če se vsaka beseda začne z zadnjo črko prejšnje in če se nobena beseda ne ponovi.


def preveri_zaporedje(besede):
         s = len(besede)
         i=0
         rez = ni_ponavljanj(besede)
         if rez is False:
             return False
         else:
             while i< (s-1):
                if lahko_sledi(besede[i],besede[i+1]) is False :
                    return False
                i += 1

         return True


from string import ascii_uppercase

#DODATNA NALOGA :


#ki vrne 0, če jih podaš A, 1 če ji podaš B ... in 25, če jih podaš Ž.
# Funkcija nekako deluje tudi za angleške črke, le da postavi Q na mesto Č-ja, W na Š in Y na Ž, X-a pa nikamor,
# saj večina angleških besed nima navade začenjati se na X.
def indeks(crka) -> object:
    crka = {"Q": "Č", "W" :"Š", "Y": "Ž"}.get(crka, crka)
    return "ABCČDEFGHIJKLMNOPRSŠTUVZŽ".index(crka)
#creating function for zero list
def zero(n):
    lists = [0] * n
    return lists


def pogostosti_zacetnic(slovar):
    i=0
    s= len(slovar)
    listl=zero(25)

    while i < s:
        p=slovar[i][0]
        z=indeks(p)
        listl[z]+=1
        i+=1

    return listl




# prejme seznam besed, zapisanih z velikimi črkami, in vrne seznam s 25 elementi.
# Prvi element pove, koliko besed v slovarju se začne s črko A, drugi, koliko besed se začne s črko B in tako naprej do Ž.





#mozne_naslednje(beseda, slovar) prejme besedo in slovar možnih besed. Vrne seznam vseh besed, ki se začnejo z zadnjo črko podane besede.

def mozne_naslednje(beseda,slovar):
    lastchar=beseda[-1:] #getting the last character from the word
    i=0
    length=len(slovar)#getting the length of the list
    listpossible=[]
    j=0
    while i<length:
        firstchar=slovar[i][0] #getting the first char of i-th word in the list
        if firstchar == lastchar:
            listpossible.insert(j,slovar[i])#inserting the word in the list of possible words
            j=j+1
        i=i+1
    return listpossible
#najboljsa_naslednja(moznosti, pogostosti) prejme seznam možnih naslednjih besed (torej točno seznam, kakršnega vrača funkcija mozne_naslednje) in seznam, ki pove, koliko besed
# se začna s posamezno črko
# (torej točno seznam, kakršnega vrača funkcija pogostosti_zacetnic).
# Med podanimi moznostmi poišče in vrne tisto besedo, ki se konča s črko, s katero se začne največ besed (pri čemer ne sme upoštevati te besede, če se slučajno začne in konča z isto črko).
# Če je enako pogostih več, vrne tisto, ki je prej po abecedi. Dolžina ni pomembna.




























