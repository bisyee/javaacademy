# Napiši funkcijo preberi_orbite(ime_datoteke), ki kot argument prejme datoteko z lunami v takšni obliki:

def preberi_orbite(ime_datoteke):
    d = {}
    with open(ime_datoteke) as f:
        for line in f:
            (val,key) = line.split(")")
            key= key.rstrip()
            d[key] = val
    return d

def lune(orbite):
    inv_lune = {}
    for key, value in orbite.items():
        if value in inv_lune:
            inv_lune.get(value,{})
            v1 = inv_lune[value]
            v1.add(key)
        else:
            v1 = set()
            v1.add(key)
            inv_lune[value] = v1
    sortedlune = {key:inv_lune[key] for key in sorted(inv_lune.keys())}
    return sortedlune

def prestej_korake(odkod, kam, orbite):
    count=1
    list = [k for k in orbite.keys()]
    print(list)
    while count<=len(list):
        if odkod in orbite:
            if orbite[odkod] != kam:
                odkod = orbite[odkod]
                count += 1
            else:
               return count
        else:
            return 0

def prestej_korake_r(odkod,kam,orbite):
    if odkod != kam:
        return 1+prestej_korake_r(orbite[odkod],kam,orbite)
    else:
        return 0

def n_odvisnikov(luna,orbite):
    lune1=[]
    count=0
    orbite= lune(orbite)
    if luna not in orbite.keys():
        return 0
    else:
        if len(orbite[luna])>1:
            for i in orbite[luna]:
                lune1.append(i)
        else:
             for i in orbite[luna]:
                lune1.append(i)
        for x in lune1:
            if x not in orbite.keys():
                count += 1
            else:
                for i in orbite[x]:
                    lune1.append(i)
    return len(lune1)


def pot_do(odkod, kam, orbite):
    pot = []
    key=odkod

    while True:
        pot.append(key)
        if key == kam:
            break
        val= orbite[key]
        pot.append(val)
        if val == kam:
            break
        key=orbite[val]
    return pot

def pot_v_niz(pot):
    list= pot
    s=" "
    for i in list:
        s+=i + " -> "
    s = s[1 :-4]
    return s

def navodila(pot, ime_datoteke):
    pot=pot.split(" -> ")
    i=2
    file=open(ime_datoteke, "w")
    if len(pot) == 1:
        file.write("Vaš cilj, " + pot[0]+ ", bo pod vami.")
    else:
        file.write("Iz " + pot[0] + " pojdite na " + pot[1] +".\n")
        while  i < len(pot):
            file.write("Potem zavijte na "+ pot[i] + ".\n")
            i += 1
        file.write("Vaš cilj, " + pot[-1] + ", bo pod vami.")
        file.close()

def odvisniki(luna,orbite):
    lune1=[]
    count=0
    orbite= lune(orbite)
    if luna not in orbite.keys():
        return set()
    else:
        if len(orbite[luna])>1:
            for i in orbite[luna]:
                lune1.append(i)
        else:
             for i in orbite[luna]:
                lune1.append(i)
        for x in lune1:
            if x not in orbite.keys():
                count += 1
            else:
                for i in orbite[x]:
                    lune1.append(i)
    return set(lune1)


def pot_do_r(odkod, kam, orbite):
    if odkod == kam:
        return [odkod]
    else:
        return [odkod] + pot_do_r(orbite[odkod], kam, orbite)

# Napiši funkcijo prestej_korake(odkod, kam, orbite), ki dobi začetno in končno luno ter slovar, kakršnega vrača funkcija preberi_orbite.
# Vrniti mora število korakov od odkod do kam, pri čemer je en korak skok z lune "dol" na luno oz. planet,
# okrog katere ta luna kroži (torej vedno samo z desne strani proti levi strani slike).

# Napiši funkcijo n_odvisnikov(luna, orbite), ki prešteje, koliko lun kroži okrog lune luna in okrog teh lun, in okrog lun,
# ki krožijo okrog teh lun in tako do konca. Z drugimi besedami, za podano luno vrne število vseh lun, ki so povezane z njo s povezavami proti desni



