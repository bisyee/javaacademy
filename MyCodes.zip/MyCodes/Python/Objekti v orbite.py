
class Luna():
    def __init__(self):
        self.list =  []
        self.number =   0
        self.mass = 0

    # gi vmetvit site luni
    def pripni(self, ime ):
        self.list.append(ime)
        # self.list=set(self.list)

    def lune(self ):
        return set(self.list)

    def ima_luno(self, ime):
        for i in self.list:
            if i == ime:
                return True
        return False

    def stevilo_lun(self):
        return len(self.list)


class EkskluzivnaLuna (Luna):
    def __init__(self):
        super().__init__()

    def pripni(self, ime):
        super().pripni(ime)
        if len(self.list) > 3:
            del self.list[0]
#ima_luno(ime)returns Trueif there is a moon with a given name among the moons orbiting that moon, and Falseif not


#konstruktor - napiši ga, če se ti zdi potrebno. Ne sprejema argumentov, stori pa naj, kar se ti zdi pametno.
#pripni(ime) si zabeleži, da okrog te lune kroži (tudi) luna z imenom ime. Metoda ne vrne ničesar.
