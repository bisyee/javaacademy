
stiki = {"Ana": {"Berta": {"šola", "sprehod", "žurka"},
                  "Cilka": {"sprehod", "trgovina"}},
          "Berta": {"Dani": {"sprehod"},
                    "Ema": {"šola", "žurka"}},
          "Cilka": {"Fanči": {"sprehod"},
                    "Greta": {"sprehod"}},
          "Dani": {"Helga": {"sprehod", "šola"}},
          "Ema": {"Iva": {"žurka"},
                  "Jana": {"šola", "žurka"}},
          "Greta": {"Klara": {"šola", "žurka"},
                    "Liza": {"trgovina", "šola", "žurka"},
                    "Micka": {"trgovina", "žurka"}},
          "Liza": {"Nina": {"trgovina", "šola"},
                   "Olga": {"šola"}}
          }



def stevilo_okuzenih1(oseba):
    list = [ ]
    if oseba not in stiki:
        return 0
    else:
        endangered_activies = stiki[oseba]
        endangered_activies1 = endangered_activies.keys()
        for i in endangered_activies1:
            list.append(i)

    for i in list:
        if i != oseba:
           for j in stiki[i]:
               for k in endangered_activies:
                    if j == k:
                     stv_okuzenih += 1
           else:


    return  len(list) +1




print(stevilo_okuzenih1("Ema"))