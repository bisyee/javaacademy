def samoopisno(n):
    lista_s=[int(i) for i in str(n)]
    j=0
    set=0
    while j <= len(lista_s)-1:
        if lista_s[j] == lista_s.count(j):
            set+=1
        j=j+1
    return set == len(lista_s)


def vsa_samoopisna(d):#d number of cipher that the samoopisnostevilo consists
    if d>7:
        print("Enter a number with less than 7 digits")
    s=[]
    j=0
    for x in range(pow(10,(d-1)), (d-1)*pow(10,(d-1))):
        if  samoopisno(x) == True and len(str(x)) == d:
            s.insert(j,x)
            j=j+1

    return s


#Napiši funkcijo pretvori(n, b), ki vrne niz s številom n, zapisanim v številskem sistemu z osnovo b.

def pretvori(n,b):
    list=[]
    j=0
    d=0
    p=1
    number=0
    while n >= 1:
        d=int(n%b)

        list.insert(j,d)
        n=int(n/b)

        j=j+1
    for x in list:
        number+= x*p
        p *= 10
    number= str(number)
    return number


def samoopisno_b(n,b):
    return samoopisno(pretvori(n,b))

print(vsa_samoopisna(4))
print(vsa_samoopisna())











