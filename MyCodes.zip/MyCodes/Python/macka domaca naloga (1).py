def preberi(ime_datoteke):
    datoteke = open(ime_datoteke, 'r')
    sirina =( datoteke.readline())
    sirina = int(sirina.strip('\n'))

    l = []
    for line in datoteke:
        line = [char for char in line]
        del line[-1]
        l.append(line)
    return sirina, l

def zdruzi(skupno, nova_vrstica):
     new=([a if a != '?' else b for a, b in zip(skupno,nova_vrstica)])
     skupno.clear()
     for i in new:
         skupno.append(i)

def sestavi(vrstice):
    for count in range(0,len(vrstice)):
        zdruzi(vrstice[0],vrstice[count])
    return vrstice[0]
def  shrani_sliko(slika, sirina, ime_datoteke):
    lista=[]
    with open(ime_datoteke, 'w') as f:
        for count, element in enumerate(slika, 1):
            if count%sirina==0:
                lista.append(" ")
                f.writelines(lista)
                f.writelines('\n')
                lista=[]
            else:
                f.write(element)
    return f
def dekodiraj(kodirana_slika, dekodirana_slika):
    sirina,l=preberi(kodirana_slika)
    sliko=sestavi(l)
    shrani_sliko(sliko,sirina,dekodirana_slika)







