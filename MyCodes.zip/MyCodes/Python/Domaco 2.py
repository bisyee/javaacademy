from math import *
from random import *
kovancev = 10

while kovancev > 0:
     stava = int(input("Stava? "))
     rand_num = randint(1, 6)
     if stava > kovancev:
         kovancev -=1
         print("Goljuf! Za kazen ti vzamem en kovanec! Imaš " + str(kovancev))
     else:
        if rand_num % 2 == 1:
         kovancev -= stava
         print("Izgubil stavo, imaš " + str(kovancev))
        else:
         kovancev += stava
         print("Dobil stavo, imaš " + str(kovancev))










