end = 0

while True:
    game =  input('Write word: ')
    if game.endswith('ka'):
        print('Calodont!')
        end = 'Caladont'

    else:
        print('Write a new word')
    if end =='Caladont':
        break
def izberi_besedo(beseda,slovar):
    for beseda in   range(0,):
       beseda: str=input(str("Write down words that are starting "))
       slovar=[]
    largestWord = ""
    largestLen = 0
    for beseda in slovar:
        if largestWord < len(beseda):
            largestWord = len(beseda)
            largestWord = beseda
    print(largestWord)

print(izberi_besedo('beseda','slovar'))
