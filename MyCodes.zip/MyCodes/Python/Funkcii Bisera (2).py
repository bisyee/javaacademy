def lahko_sledi(prej,potem):
    if prej!=potem and prej[-1:] == potem[0]:
        return True
    else:
        return False
def izberi_besedo(beseda, slovar):
    e = len(slovar)  # Getting the number of elements in the list
    i = 0
    number = 1
    listofl = []
    largestWord = ""

    while i <=e-1:
        if lahko_sledi(beseda, slovar[i]) is True:
                if len(largestWord) == len(slovar[i]):
                        listofl.insert(number,largestWord)#Writing the first word
                        number += 1#Incrementing to go on the next element of the list
                        listofl.insert(number, slovar[i])#Writing the second element of the list

                elif  len(largestWord) < len(slovar[i]):
                    largestWord = slovar[i]
        i += 1
        if number > 1:#Sorting if there are more elements with the same size
           listofl.sort()  # Sorting the list of largest number by alphabetical order
           print(listofl)
           largestWord = listofl[0]

    return largestWord
def ni_ponavljanj(besede):

    # if len(besede) == len(set(besede)):
    #     return True
    # else:
    #     return False

    s = len(besede)
    i = 0
    j = 0
    while i < s:
        j = i + 1
        while j < s:
            if besede[j] == besede[i]:
                return False
            j += 1
        i += 1
    return True


def preveri_zaporedje(besede):
    s = len(besede)
    i = 0
    rez = ni_ponavljanj(besede)
    if rez is False:
        return False
    else:
        while i < (s - 1):
            if lahko_sledi(besede[i], besede[i + 1]) is False:
                return False
            i += 1

    return True
def indeks(crka) -> object:
    crka = {"Q": "Č", "W" :"Š", "Y": "Ž"}.get(crka, crka)
    return "ABCČDEFGHIJKLMNOPRSŠTUVZŽ".index(crka)
#creating function for zero list
def zero(n):
    lists = [0] * n
    return lists


def pogostosti_zacetnic(slovar):
    i=0
    s= len(slovar)
    listl=zero(25)

    while i < s:
        p=slovar[i][0]
        z=indeks(p)
        listl[z]+=1
        i+=1

    return listl

def mozne_naslednje(beseda,slovar):
    lastchar=beseda[-1:] #getting the last character from the word
    i=0
    length=len(slovar)#getting the length of the list
    listpossible=[]
    j=0
    while i<length:
        firstchar=slovar[i][0] #getting the first char of i-th word in the list
        if firstchar == lastchar:
            listpossible.insert(j,slovar[i])#inserting the word in the list of possible words
            j=j+1
        i=i+1
    return listpossible






def vsa_drevesa(gozd):
    return [koordinat  and koordinat.append(i,j) if je_drevo(i,j,gozd)  for i in range(0 , dimenzije(gozd)[0])  for x in range(0, dimenzije(gozd)[1]) ]





