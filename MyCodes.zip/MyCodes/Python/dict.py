dict={Ana: 5.12, Berta: 4.48, Cilka: 5.05, Dani: 10.12,Ema: 4.45}
dict= {k:v for k ,v in sorted(dict.items, key=lambda item: item[1])}
print(dict)