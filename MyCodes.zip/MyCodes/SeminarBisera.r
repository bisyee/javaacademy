#So we are building classification model based on the variable "Poraba"

porabat <-  read.table("dataSem1.txt", sep=",", header=T, stringsAsFactors=T)
summary(porabat)




porabat$datum <- NULL
porabat$poraba<-NULL


set.seed(0)

samplec<- sample(1:nrow(porabat), size = as.integer(nrow(porabat) * 0.7), replace = F)

train<- porabat[samplec,]
test<- porabat[-samplec,]



summary(porabat)




table(train$norm_poraba)
table(test$norm_poraba)


library(nnet)
obsMat <- class.ind(test$norm_poraba)

observed <- test$norm_poraba
predicted <- predict(dt, test, type="class")

tab <- table(observed, predicted)



q <- observed == predicted
mean(q)







CA <- function(observed, predicted)
{
	mean(observed == predicted)
}

brier.score <- function(observedMatrix, predictedMatrix)
{
	sum((observedMatrix - predictedMatrix) ^ 2) / nrow(predictedMatrix)
}




#classification model 1 decision tree

library(rpart)
dt <- rpart("norm_poraba ~ povrsina + namembnost + temp_zraka",  data = train, cp =0)
library(rpart.plot)
rpart.plot(dt)


printcp(dt)
tab <- printcp(dt)


row <- which.min(tab[,"xerror"])
th <- mean(c(tab[row, "CP"], tab[row-1, "CP"]))
th


dt <- prune(dt, cp=th)
rpart.plot(dt)





predicted <- predict(dt, test, type="class")
CA(observed, predicted)

predMat <- predict(dt, test, type = "prob")
brier.score(obsMat, predMat)





#Classification model 2  with random forest
library(CORElearn)
rf <- CoreModel(norm_poraba ~ ., data = train, model="rf")
predicted <- predict(rf, test, type="class")
CA(observed, predicted)

predMat <- predict(rf, test, type = "prob")
brier.score(obsMat, predMat)


predMat <- predict(dt, test, type = "prob")
brier.score(obsMat, predMat)


#Classification model 3 with naive Bayes


library(e1071)

nb <- naiveBayes(norm_poraba ~ ., data = train)
predicted <- predict(nb, test, type="class")
CA(observed, predicted)

predMat <- predict(nb, test, type = "raw")
brier.score(obsMat, predMat)






##############################################Regresija############################################################################


# linearna regresija


porabac <-  read.table("dataSem1.txt", sep=",", header=T, stringsAsFactors=T)

porabac$datum <- NULL
porabac$norm_poraba<-NULL

set.seed(0)

samplec<- sample(1:nrow(porabac), size = as.integer(nrow(porabac) * 0.7), replace = F)

train<- porabac[samplec,]
test<- porabac[-samplec,]




rmae <- function(obs, pred, mean.val) 
{  
	sum(abs(obs - pred)) / sum(abs(obs - mean.val))
}


# srednja absolutna napaka
mae <- function(obs, pred)
{
	mean(abs(obs - pred))
}


mae(observed, predicted)
mse(observed, predicted)


##########################################
meanVal <- mean(train$poraba)
meanVal



#Linear regression model 1 


model <- lm(poraba ~ ., train)
model

predicted <- predict(model, test)

observed <- test$poraba

plot(observed)
points(predicted, col="red")
mae(observed, predTrivial)
rmae(observed, predicted, mean(train$poraba))


#################################################################################################

#Regression model 2  regression tree

library(rpart)
library(rpart.plot)

rt.model <- rpart(poraba ~ ., data=train)
rpart.plot(rt.model)
predicted <- predict(rt.model, test)
mae(test$poraba, predicted)
rmae(test$poraba, predicted, mean(train$poraba))


#Regression model 3  neural network

library(nnet)

set.seed(0)
nn.model <- nnet(poraba ~ ., train, size = 5, decay = 0.0001, maxit = 10000, linout = T)
predicted <- predict(nn.model, test)
mae(test$poraba, predicted)
rmae(test$poraba, predicted, mean(train$poraba))


