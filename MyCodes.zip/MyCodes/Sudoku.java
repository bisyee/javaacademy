import java.util.*;

public class Sudoku
{
        static int[][] fields = new int[9][9];
        static boolean[][] staticFields = new boolean[9][9];

        //number of starting fields
        static int staticfieldsNum = 30;

        public static final String ANSI_RESET = "\u001B[0m";
        public static final String ANSI_GREEN = "\u001B[32m";

        public static void main(String[] args) {
            boolean loop = true;
            while(loop){
                check1();
                if(insertValue(0, 0)){
                    fieldsToString();
                    loop = false;
                }
            }
        }

        public static void check1() {
            Random rnd = new Random();
            for (int i = 0; i < 9; i++) {
                for (int j = 0; j < 9; j++) {
                    fields[i][j] = 0;
                }
            }

            for(int i=0; i<staticfieldsNum; i++){
                int x = rnd.nextInt(9);
                int y = rnd.nextInt(9);
                int num = rnd.nextInt(9) + 1;
                if(checkField(x,y,num) && !staticFields[x][y]){
                    staticFields[x][y] = true;
                    fields[x][y] = num;

                }
            }
        }

        public static boolean checkField(int x, int y, int val) {
            for (int i = 0; i < 9; i++) {
                if (fields[x][i] == val || fields[i][y] == val) {
                    return false;
                }
            }
            int start_x = (x / 3) * 3;
            int start_y = (y / 3) * 3;
            for (int i = start_x; i < start_x + 3; i++) {
                for (int j = start_y; j < start_y + 3; j++) {
                    if (fields[i][j] == val) {
                        return false;
                    }
                }
            }
            return true;
        }

        public static boolean insertValue(int x, int y) {
            if (x == 9) {
                return true;
            }
            if (staticFields[x][y]) {
                if (insertValue(y == 8 ? x + 1 : x, (y + 1) % 9)) {
                    return true;
                }
            } else {
                for (int i = 0; i < 9; i++) {
                    if (checkField(x, y, i + 1)) {
                        fields[x][y] = i + 1;

                        if (insertValue(y == 8 ? (x + 1) : x, (y + 1) % 9)) {
                            return true;
                        } else {
                            fields[x][y] = 0;
                        }
                    }
                }
            }
            return false;
        }

        public static void fieldsToString() {
            System.out.print("---Bisyee's Sudoku Algorithm:---");
            System.out.println();
            for (int j = 0; j < 13; j++) {
                System.out.print(" -");
            }
            System.out.println("");
            for (int i = 0; i < 9; i++) {
                for (int j = 0; j < 9; j++) {
                    if (j == 0 || j % 3 == 0) {
                        System.out.print(" |");
                    }

                    if(staticFields[i][j])
                        System.out.print(" " + ANSI_GREEN+fields[i][j]+ANSI_RESET);
                    else
                        System.out.print(" " + fields[i][j]);

                    if (j == 8) {
                        System.out.print(" |");
                    }
                }
                if ((i + 1) % 3 == 0) {
                    System.out.println("");
                    for (int j = 0; j < 13; j++) {
                        System.out.print(" -");
                    }
                }
                System.out.println("");
            }
        }
    }


