import pandas as pd

import matplotlib.pyplot as plt
import csv
from sklearn.model_selection import train_test_split
import statsmodels.api as sm
import pylab
from math import sqrt
from scipy import stats
from statsmodels.regression.linear_model import OLS
from sklearn.metrics import r2_score
import numpy as np

from sklearn.linear_model import LinearRegression



dataset = pd.read_csv('/Users/User/Desktop/Seminarska/podatki_zavor.csv')


print(dataset.shape)
print(dataset.describe())

x = []
y = []

with open('/Users/User/Desktop/Seminarska/podatki_zavor.csv', "r", encoding="utf8") as f:
    reader = csv.reader(f, delimiter="\t")

    # get number of columns
    for line in f.readlines():
        array = line.split(',')
        x.append(array[0])
        y.append(array[1].rstrip("\n"))
    x.pop(0)
    y.pop(0)

x = [int(i) for i in x]
y = [float(i) for i in y]
sqrtx = [sqrt(i) for i in y]
################################################################################
plt.scatter(x, sqrtx, color='blue')
plt.title('Hitrost vs Pot')
plt.xlabel('hitrost')
plt.ylabel('pot')
plt.show()
# correlation
#################################################################################
x_np = np.array(x)
y_np = np.array(sqrtx)


def plotter(slope, intercept):
    """Plot a line from slope and intercept, borrowed from https://stackoverflow.com/questions/7941226/how-to-add-line-based-on-slope-and-intercept-in-matplotlib"""
    axes = plt.gca()
    x_vals = np.array(axes.get_xlim())
    y_vals = intercept + slope * x_vals
    plt.plot(x_vals, y_vals, '--')


model = OLS(y_np,sm.tools.add_constant(x_np))
results = model.fit()
# predict y values for training data
y_predicted = model.predict(results.params)
# plot predicted vs actual
plt.plot(y_predicted, y_np, 'o')
plt.xlabel('Predicted')  # ,color='white')
plt.ylabel('Actual')  # ,color='white')
plt.title('Predicted vs. Actual: Visual Linearity Test')  # ,color='white')
plt.tick_params(axis='x', colors='white')
plt.tick_params(axis='y', colors='white')
plotter(1, 0)
plt.show()
#################################################################################################


stats.probplot(y_np-y_predicted, dist="norm", plot=pylab)
pylab.title('Normality of graph')
pylab.show()

#############################################################################################
print(y_predicted)
print(y_np)
plt.plot(y_predicted,y_np-y_predicted,'o')
plt.xlabel(r'Predicted \hat{y}')
plt.ylabel(r'Residuals y-\hat{y}')
plt.title('Heteroscedasticity of graph')
plt.tick_params(axis='x')
plt.tick_params(axis='y')
plt.show()

#############################################################################################


#coefficient of determination
scored=r2_score(y_predicted, y_np)
print("Coefficient of determination" )
print(scored)

###########################################33

#Actual vs predicted
df = pd.DataFrame({'Actual':y_np.flatten(), 'Predicted': y_predicted.flatten()})
print(df)

B = np.reshape(x, (-1, 2))
C = np.reshape(sqrtx, (-1, 2))

regressor = LinearRegression()
regressor.fit(B, C) #training the algorithm


#To retrieve the intercept:
print("Intercept" )
print( regressor.intercept_)
#For retrieving the slope:
print("Slope")
print( regressor.coef_)



