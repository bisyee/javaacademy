#numerical libraries
import pandas as pd
import numpy as np
#plotting and visualization
import seaborn as sns
from matplotlib import pyplot as plt
import matplotlib
from scipy import stats

train = pd.read_csv("Users/User/Desktop/Seminarska/podatki_zavor.csv")
test = pd.read_csv("Users/User/Desktop/Seminarska/podatki_zavor.csv")
all_data = pd.concat((train.loc[:,'MSSubClass':'SaleCondition'],
                       test.loc[:,'MSSubClass':'SaleCondition']))
matplotlib.rcParams['figure.figsize'] = (12.0, 6.0)
prices = pd.DataFrame({"price":train["SalePrice"], "log(price + 1)":np.log1p(train["SalePrice"])})
all_data = pd.get_dummies(all_data)
#filling NA's with the mean of the column:
all_data = all_data.fillna(all_data.mean())
#creating relevant matrices:
X_train = all_data[:train.shape[0]]
X_test = all_data[train.shape[0]:]
y = train.SalePrice
X_train_np = np.array(X_train)
y_np = np.array(y)


def abline(slope, intercept):
    """Plot a line from slope and intercept, borrowed from https://stackoverflow.com/questions/7941226/how-to-add-line-based-on-slope-and-intercept-in-matplotlib"""
    axes = plt.gca()
    x_vals = np.array(axes.get_xlim())
    y_vals = intercept + slope * x_vals
    plt.plot(x_vals, y_vals, '--')


# fit an OLS model to data
model = OLS(y_np, sm.tools.add_constant(X_train_np))
results = model.fit()
# predict y values for training data
y_hat = model.predict(results.params)
# plot predicted vs actual
plt.plot(y_hat, y_np, 'o')
plt.xlabel('hitrost')  # ,color='white')
plt.ylabel('pot')  # ,color='white')
plt.title('Predicted vs. Actual: Visual Linearity Test')  # ,color='white')
plt.tick_params(axis='x', colors='white')
plt.tick_params(axis='y', colors='white')
abline(1, 0)
plt.show()