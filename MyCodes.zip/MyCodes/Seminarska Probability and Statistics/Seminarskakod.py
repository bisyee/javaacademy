import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import csv
import seaborn as seabornInstance
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn import metrics
import scipy.stats as stats
import statsmodels.api as sm
import pylab
from math import sqrt
import statistics
from scipy import stats

dataset = pd.read_csv('/Users/User/Desktop/Seminarska/podatki_zavor.csv')


print(dataset.shape)
print(dataset.describe())

x=[]
y=[]


with open('/Users/User/Desktop/Seminarska/podatki_zavor.csv', "r", encoding="utf8") as f:
    reader = csv.reader(f, delimiter="\t")

    # get number of columns
    for line in f.readlines():
        array = line.split(',')
        x.append(array[0])
        y.append(array[1].rstrip("\n"))
    x.pop(0)
    y.pop(0)

x = [int(i) for i in x]
y = [float(i) for i in y]
sqrtx= [sqrt(i) for i in y]
################################################################################
plt.scatter(x, sqrtx,  color='blue')
plt.title('Hitrost vs Pot')
plt.xlabel('hitrost')
plt.ylabel('pot')
#correlation
#################################################################################



X = dataset['hitrost'].values.reshape(-1,1)
Y = dataset['pot'].values.reshape(-1,1)

X_train, X_test, y_train, y_test = train_test_split(X, Y, test_size=0.2, random_state=0)

regressor = LinearRegression()
regressor.fit(X_train, y_train) #training the algorithm
y_pred = regressor.predict(X_test)

#To retrieve the intercept:
print(regressor.intercept_)
#For retrieving the slope:
print(regressor.coef_)

#bar graph of  the comparison of actual and predicted values
df = pd.DataFrame({'Actual': y_test.flatten(), 'Predicted': y_pred.flatten()})
print(df)
df1 = df.head(25)
df1.plot(kind='bar',figsize=(16,10))
plt.grid(which='major', linestyle='-', linewidth='0.5', color='green')
plt.grid(which='minor', linestyle=':', linewidth='0.5', color='black')
plt.show()

residuals = y_test-y_pred



plt.scatter(X_test, y_test,  color='gray')
plt.plot(X_test, y_pred, color='red', linewidth=2)
plt.show()


stats.probplot(x, dist="norm", plot=plt)
plt.show()

print('Mean Absolute Error:', metrics.mean_absolute_error(y_test, y_pred))
print('Mean Squared Error:', metrics.mean_squared_error(y_test, y_pred))
print('Root Mean Squared Error:', np.sqrt(metrics.mean_squared_error(y_test, y_pred)))




tab=[]

for i in residuals:
    for j in i:
        tab.append(j)

tab=[float(i) for i in tab]
print(stats.describe(tab))