import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.*;

public class DN09 {
    static class Position{
        int x;
        int y;


        public int sestevanje(int x, int y){
            return x+y;
        }

        public int odštevanje(int x, int y){
            return x-y;
        }

        public int razdalja(int x1, int y1, int x2, int y2){
            return Math.max(Math.abs(x2-x1), Math.abs(y2-y1));
        }
    }

    static class Human{
        boolean isInfected;
        boolean hasSymptoms;
        Position position;
        boolean behavior;
        UnawareBehavior unawareBehavior;
        AwareBehavior awareBehavior;
        double probabilityInfection;
        double probabilityTrueSymptoms;
        double probabilityFakeSymptoms;

        public Human(){
            position = new Position();
            unawareBehavior = new UnawareBehavior();
            awareBehavior = new AwareBehavior();
        }

    }

    abstract static class Behavior{
        abstract void update(Human human, Human[] neighborhood);

    }

    static class UnawareBehavior extends Behavior{
        @Override
        void update(Human human, Human[] neighborhood) {
            human.position.x = new Random().nextInt(3) + 1;
            human.position.y = new Random().nextInt(3) + 1;
        }
    }

    static class AwareBehavior extends Behavior{
        @Override
        void update(Human human, Human[] neighborhood) {
            int sumX = 0;
            int sumY = 0;
            for (Human neighbour: neighborhood){
                sumX += neighbour.position.x;
                sumY += neighbour.position.y;
                if (neighbour.hasSymptoms || neighbour.isInfected)
                    human.behavior = true;
            }

            sumX /= neighborhood.length;
            sumY /= neighborhood.length;

            int razdalja = 0;
            for (int i=1; i<4; i++){
                for (int j=1; j<4; j++) {
                    if (human.position.razdalja(i, j, sumX, sumY) > razdalja) {
                        razdalja = human.position.razdalja(i, j, sumX, sumY);
                        human.position.x = i;
                        human.position.y = j;
                    }
                }
            }


        }
    }

    static class Simulation extends Behavior{

        public boolean isAware(Human human, Human[] neighborhood){
            for (Human human1: neighborhood){
                if (human1.hasSymptoms || human1.isInfected)
                    return true;
            }
            return false;
        }


        @Override
        void update(Human human, Human[] neighborhood) {
            List<Integer> generatedList = new ArrayList<>();
            int randomNum = new Random().nextInt(0) + neighborhood.length;
            if (generatedList.contains(randomNum)){
                randomNum = new Random().nextInt(0) + neighborhood.length;
            }
            generatedList.add(randomNum);
            Human humanTrenutni = neighborhood[randomNum];
            if (isAware(humanTrenutni, neighborhood)){
                humanTrenutni.awareBehavior.update(humanTrenutni, neighborhood);
                humanTrenutni.probabilityInfection += humanTrenutni.probabilityTrueSymptoms;
            }else {
                humanTrenutni.unawareBehavior.update(humanTrenutni, neighborhood);
                humanTrenutni.probabilityInfection -= humanTrenutni.probabilityFakeSymptoms;
            }


            Human[] neighborhoodTemp = neighborhood;
        }
    }




    public static void main(String[] args) throws FileNotFoundException {

        Scanner sc = new Scanner(new FileReader(new File("args[0]")));

        Simulation simulation = new Simulation();

        int numberOfHumans = 0;
        double probabilityInfection = 0.0;
        double probabilityTrueSymptoms = 0.0;
        double probabilityFakeSymptoms = 0.0;
        int steps = 0;
        int neighborhoodRadius = 0;
        List<Human> humans = new ArrayList<>();
        int nakljucnoStevilo = 0;
        int x1 = 0;
        int x2 = 0;
        int y1 = 0;
        int y2 = 0;
        Human human = new Human();

        while (sc.hasNextLine()){
            String ukaz = sc.nextLine();
            String[] delovi = ukaz.split(" ");

            if (delovi[0].equals("numberOfHumans")){
                numberOfHumans = Integer.parseInt(delovi[1]);
            }if (delovi[0].equals("human ")){
                human = new Human();
                human.position.x = Integer.parseInt(delovi[1]);
                human.position.y = Integer.parseInt(delovi[2]);
                human.isInfected = Boolean.parseBoolean(delovi[3]);
                human.hasSymptoms = Boolean.parseBoolean(delovi[4]);
                humans.add(human);
            }if (delovi[0].equals("random")){
                nakljucnoStevilo = Integer.parseInt(delovi[1]);
                x1 = Integer.parseInt(delovi[4]);
                x2 = Integer.parseInt(delovi[5]);
                y1 = Integer.parseInt(delovi[7]);
                y2 = Integer.parseInt(delovi[8]);


            }if (delovi[0].equals("neighborhoodRadius")){
                neighborhoodRadius  = Integer.parseInt(delovi[1]);
            }if (delovi[0].equals("steps")){
                steps = Integer.parseInt(delovi[1]);
            }if (delovi[0].equals("probabilityInfection")){
                probabilityInfection = Double.parseDouble(delovi[2]);
            }if (delovi[0].equals("probabilityTrueSymptoms")){
                probabilityTrueSymptoms = Double.parseDouble(delovi[2]);
            }if (delovi[0].equals("probabilityFakeSymptoms")){
                probabilityFakeSymptoms = Double.parseDouble(delovi[2]);
            }
        }

        for (int i=0; i<numberOfHumans; i++){
            simulation.update(human, (Human[]) humans.toArray());
        }

    }


    }






