import java.awt.Color;
import java.util.Random;

import java.awt.*;
public class DNO6 {

    public static void korona(double x, double y, double velikost){

        StdDraw.setPenColor(StdDraw.DARK_GRAY);
        StdDraw.filledCircle(x, y, velikost);
        StdDraw.setPenColor(134,0,0);
        StdDraw.setPenRadius(0.01);
        double p=0.2;
        double r=0.05;
        for(int i=0; i<2; i++) {
            StdDraw.line(x - velikost, y, x - velikost - p, y);
            StdDraw.filledCircle(x - velikost - p , y, r);
            StdDraw.line(x,  y+velikost+p, x, y+velikost);
            StdDraw.filledCircle(x, y+velikost+p,r);
            StdDraw.line(x+velikost-p,  y-velikost+p, x+velikost, y-velikost);
            StdDraw.filledCircle(x+velikost, y-velikost,r);
            StdDraw.line(x+velikost-p,  y+velikost-p, x+velikost, y+velikost);
            StdDraw.filledCircle(x+velikost, y+velikost,r);

            p*=-1;
            velikost*=-1;
        }
    }
    public static void main(String[] args){
        StdDraw.setCanvasSize(1280,1280);
        StdDraw.setXscale(0,15);
        StdDraw.setYscale(0,15);
        double radius=0.3;
        for(int i=0; i<10;i++){
            Random rn = new Random();
            int x = rn.nextInt(15) + 1;
            int y=rn.nextInt(15) + 1;
            korona(x,y,radius);
            radius+=0.05;

        }

    }
}
