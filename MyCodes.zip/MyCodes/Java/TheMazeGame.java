


import java.io.File;
import java.util.*;
import java.io.FileReader;
import java.io.*;
import java.util.Scanner;


public class TheMazeGame {
         public static int[][] a;
        public static int[][] preberiLabirint(String ime) throws FileNotFoundException {
            String[] delovi = ime.split("_");
            delovi[2] = delovi[2].substring(0,delovi[2].length() - 4);
            int[][] tabela = new int[Integer.parseInt(delovi[2]) * 2 - 1][Integer.parseInt(delovi[1]) * 2 - 1];;
            Scanner sc = new Scanner(new FileReader(new File(ime)));
            while (sc.hasNextLine()) {
                for (int i = 0; i < tabela.length; i++) {
                    String[] line = sc.nextLine().trim().split("  ");
                    for (int j = 0; j < line.length; j++) {
                        tabela[i][j] = Integer.parseInt((line[j]));
                    }
                }
            }
            return tabela;
        }
        public static void izrisiLabirint(int[][] labirint) {
            for (int i=0; i< labirint[0].length+2; i++){
                System.out.print("# ");
            }
            System.out.print("\n");
            for (int[] ints : labirint) {
                System.out.print("# ");
                for (int anInt : ints) {
                    if (anInt == 0) {
                        System.out.print("# ");
                    } else {
                        System.out.print("  ");
                    }
                }
                System.out.print("#\n");
            }
            for (int i=0; i< labirint[0].length+2; i++){
                if(i== labirint[0].length){
                    System.out.print("  ");
                }
                else {
                    System.out.print("# ");
                }
            }
        }

        public static int[] preberiResitev(String ime) throws Exception {
            String[] delovi = ime.split("_");
            delovi[2] = delovi[2].substring(0, 1);
            Scanner sc = new Scanner(new FileReader(new File(ime)));
            String[] line = sc.nextLine().trim().split(" {2}");
            int[] tabela=new int[line.length];
            for (int i = 0; i < line.length; i++) {
                tabela[i] = Integer.parseInt(line[i]);
            }
            return tabela;
        }
        public static boolean preveriResitev(int[][] labirint, int[] resitev){
            int k=0;
            int j=0;
            boolean set=true;
            for(int i=0; i<resitev.length;i++){
                switch(resitev[i]){
                    case 2:
                        j=j;
                        break;
                    case 3:
                        j-=1;
                        break;
                    case 4:
                        j+=1;
                        break;
                    case 5:
                        k-=1;
                        break;
                    case 6:
                        k+=1;
                }
                if(labirint[k][j]==0 ||  labirint.length<j || labirint[0].length<k){
                    set=false;
                    break;
                }
            }
            return set;

        }
        public static int[][] narediLabirint(int sirina, int visina, double verjetnost) {
            int[][] tabela = new int[2 * visina - 1][2 * sirina - 1];
            for (int i = 0; i < tabela.length; i++) {
                for (int j = 0; j < tabela[0].length; j++) {
                    tabela[i][j] = 1;
                }
            }
            Random rand = new Random();
            int randomsirina = rand.nextInt(2*sirina-1);
           while(randomsirina %2 == 0){
               randomsirina = rand.nextInt(2*sirina-1);;
           }
           int randomvisina = rand.nextInt(2*visina-1);
            while(randomvisina %2 == 0) {
                randomvisina = rand.nextInt(2 * visina - 1);
            }
            for (int k = 0; k < 2 * visina - 1; k++) {
                tabela[k][randomsirina] = 0;
            }
            for (int k = 0; k < 2 * sirina - 1; k++) {
                tabela[randomvisina][k] = 0;
            }
            tabela[0][randomsirina] = 1;
            tabela[tabela.length - 1][randomsirina] = 1;
            tabela[randomvisina][0] = 1;
            tabela[randomvisina][tabela[0].length - 1] = 1;



            if(randomvisina-1>1 && randomsirina-1>1){
                return narediLabirint(randomsirina-1, randomvisina-1,  verjetnost);
            }
            if(randomvisina-1>1 && tabela[0].length-randomsirina-1>1){
                return narediLabirint(tabela[0].length-randomsirina-1, randomvisina-1,  verjetnost);
            }
            if(tabela.length-randomvisina-1>1 && randomsirina-1>1){
                return narediLabirint(randomsirina-1, tabela.length-randomvisina-1,  verjetnost);
            }
            if(tabela.length-randomvisina-1>1 && tabela[0].length-randomsirina-1>1){
                return narediLabirint(tabela[0].length-randomsirina-1, tabela.length-randomvisina-1,  verjetnost);
            }

            return tabela;

        }
        public static void shraniLabirint(int[][] labirint, String ime) throws FileNotFoundException, UnsupportedEncodingException {
            String ime1="labirint_" +Integer.toString(labirint.length) +"_"+Integer.toString(labirint[0].length)+".txt";
            System.out.print(ime1);
            PrintWriter writer = new PrintWriter(ime1, "UTF-8");
            try{
                for(int i=0;i<labirint.length;i++) {
                    for (int j = 0; j < labirint[0].length; j++) {
                        writer.print( " " + Integer.toString( labirint[i][j]  )+ " ");
                    }
                    writer.println();
                }
            }catch (Exception e){
                System.err.println("Error: " + e.getMessage());
            }
            writer.close();
        }





        public static void main(String[] args) throws Exception {
            if(args.length == 2){
            preberiLabirint(args[0]);
            izrisiLabirint(preberiLabirint(args[0]));
            preberiResitev(args[1]);
            boolean b=preveriResitev(preberiLabirint(args[0]), preberiResitev(args[1]));
            if (b){
                System.out.print("\nPravilna resitev!");

            }
            else {
                System.out.print("\nNepravilna resitev!\n");
            }
            }
            if(args.length == 3) {
                izrisiLabirint(narediLabirint(Integer.parseInt(args[0]), Integer.parseInt(args[1]), Integer.parseInt(args[2])));
                shraniLabirint(narediLabirint(Integer.parseInt(args[0]), Integer.parseInt(args[1]), Integer.parseInt(args[2])), "labirint_[sirina]_[visina].txt ");
            }


        }
    }



