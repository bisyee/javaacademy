import java.util.Scanner;

@SuppressWarnings("unchecked")
interface Collection {
    static final String ERR_MSG_EMPTY = "Collection is empty.";
    static final String ERR_MSG_FULL = "Collection is full.";

    boolean isEmpty();
    boolean isFull();
    int size();
    String toString();

}


@SuppressWarnings("unchecked")
interface Stack<T> extends Collection {
    public abstract T top() throws CollectionException;

    public abstract void push(T x) throws CollectionException;

    public abstract T pop() throws CollectionException;

}

@SuppressWarnings("unchecked")
interface Sequence<T>  extends Collection
{
    static final String ERR_MSG_INDEX = "Wrong index in sequence.";
    T get(int i) throws CollectionException;
    void add(T x) throws CollectionException;
}
@SuppressWarnings("unchecked")
class CollectionException extends Exception {
    public CollectionException(String msg) {
        super(msg);
    }
}

@SuppressWarnings("unchecked")
class ArrayDeque<T> implements Stack<T>, Sequence<T>{

    private static final int DEFAULT_CAPACITY = 64;

    private T[] a;
    private int front,back,size;

    public ArrayDeque(){
        a= (T[]) (new Object[DEFAULT_CAPACITY]);
        front=0;
        back=0;
        size=0;
    }

    @Override
    public boolean isEmpty() {
        return (size == 0);
    }

    @Override
    public boolean isFull() {
        return (size == DEFAULT_CAPACITY);
    }

    @Override
    public int size() {
        return size;
    }

    public int prev(int i){
        return (DEFAULT_CAPACITY+i-1)%DEFAULT_CAPACITY;
    }
    public int next(int i){
        return(i+1)%DEFAULT_CAPACITY;
    }


    @Override
    public T top() throws CollectionException {
        if (isEmpty()) {
            throw new CollectionException(ERR_MSG_EMPTY);
        }
        return a[prev(back)];
    }

    @Override
    public void push(T x) throws CollectionException {
        if (isFull()) {
            throw new CollectionException(ERR_MSG_FULL);
        }
        a[back] = x;
        back = next(back);
        size+=1;
    }

    @Override
    public T pop() throws CollectionException {
        if (isEmpty()) {
            throw new CollectionException(ERR_MSG_EMPTY);
        }
        back = prev(back);
        T o = a[back];
        a[back] = null;
        size-=1;
        return o;
    }
    private int index(int i){
        return (front+i)%DEFAULT_CAPACITY;
    }

    @Override
    public T get(int i) throws CollectionException {
        if (isEmpty()) {
            throw new CollectionException(ERR_MSG_EMPTY);
        }
        if (i<0 || i>=size) {
            throw new CollectionException(ERR_MSG_INDEX);
        }
        return a[index(i)];
    }

    @Override
    public void add(T x) throws CollectionException {
        if (isFull()){
            throw new CollectionException(ERR_MSG_FULL);
        }
        a[back] = x;
        back = next(back);
        size += 1;

    }
}


@SuppressWarnings("unchecked")
class ProgramabilniKalkulator1 {

    private Sequence<Stack<String>> seq1;
    private String[] line1;
    private int num;
    private Scanner scan;
    private boolean condition= true;

    public void echo() throws CollectionException{
        if(this.seq1.get(0).isEmpty()) { System.out.println();}
        else{ System.out.println(this.seq1.get(0).top());}
    }

    public void dup() throws CollectionException{
        seq1.get(0).push(seq1.get(0).top());
    }

    public void pop() throws CollectionException{
        seq1.get(0).pop();
    }
    public void dup2() throws CollectionException{
        String string1= this.seq1.get(0).pop();
        String string2= this.seq1.get(0).pop();
        seq1.get(0).push(string1);
        seq1.get(0).push(string2);
        seq1.get(0).push(string1);
    }

    public void swap() throws CollectionException{
        String string1= this.seq1.get(0).pop();
        String string2= this.seq1.get(0).pop();
        seq1.get(0).push(string2);
        seq1.get(0).push(string1);

    }

    public void character() throws CollectionException{
        String string1= this.seq1.get(0).pop();
        int i= Integer.parseInt(string1);
        char c= (char)i;
        seq1.get(0).push(String.valueOf(c));
    }

    public void factorial() throws CollectionException{
        int value= Integer.parseInt(seq1.get(0).pop());
        int s= 1;
        while(value !=0) {
            s*=value;
            value-=1;
        }
        seq1.get(0).push(String.valueOf(value));
    }

    public void length1() throws CollectionException{
        /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    }

    public void even() throws CollectionException{
          int value= Integer.parseInt(seq1.get(0).pop());
          if ( value % 2 == 0) {
              seq1.get(0).push(String.valueOf(1));
          }
          else{ seq1.get(0).push(String.valueOf(0));}
    }

    public void odd() throws CollectionException{
        int value= Integer.parseInt(seq1.get(0).pop());
        if ( value % 2 != 0) {
            seq1.get(0).push(String.valueOf(1));
        }
        else{ seq1.get(0).push(String.valueOf(0));}
    }

    public void pogolemopomalo () throws CollectionException{
        String string1= this.seq1.get(0).pop();
        String string2= this.seq1.get(0).pop();
        if ( string1.equals(string2)){
            seq1.get(0).push(String.valueOf(0));
        }
        else{
            seq1.get(0).push(String.valueOf(1));
        }
    }

    public void pomalo() throws CollectionException{
        int value1= Integer.parseInt(seq1.get(0).pop());
        int value2= Integer.parseInt(seq1.get(0).pop());
        if ( value1 < value2){
            seq1.get(0).push(String.valueOf(1));
        }
        else{
            seq1.get(0).push(String.valueOf(0));
        }
    }
    public void pogolemo() throws CollectionException{
        int value1= Integer.parseInt(seq1.get(0).pop());
        int value2= Integer.parseInt(seq1.get(0).pop());
        if ( value1 > value2){
            seq1.get(0).push(String.valueOf(1));
        }
        else{
            seq1.get(0).push(String.valueOf(0));
        }
    }

    public void ednakvo() throws CollectionException{
        int value1= Integer.parseInt(seq1.get(0).pop());
        int value2= Integer.parseInt(seq1.get(0).pop());
        if ( value1 == value2){
            seq1.get(0).push(String.valueOf(1));
        }
        else{
            seq1.get(0).push(String.valueOf(0));
        }
    }

    public void pomaloednakvo() throws CollectionException{
        int value1= Integer.parseInt(seq1.get(0).pop());
        int value2= Integer.parseInt(seq1.get(0).pop());
        if ( value1 <= value2){
            seq1.get(0).push(String.valueOf(1));
        }
        else{
            seq1.get(0).push(String.valueOf(0));
        }
    }
    public void pogolemoednakvo() throws CollectionException{
        int value1= Integer.parseInt(seq1.get(0).pop());
        int value2= Integer.parseInt(seq1.get(0).pop());
        if ( value1 >= value2){
            seq1.get(0).push(String.valueOf(1));
        }
        else{
            seq1.get(0).push(String.valueOf(0));
        }
    }



    public void operacii(String s) throws CollectionException{
        int value1= Integer.parseInt(seq1.get(0).pop());
        int value2= Integer.parseInt(seq1.get(0).pop());
        switch (s){
            case "%" : { seq1.get(0).push(String.valueOf(value1%value2));}
            case "/" : {seq1.get(0).push(String.valueOf(value1/value2));}
            case "*" : {seq1.get(0).push(String.valueOf(value1*value2));}
            case "-" : {seq1.get(0).push(String.valueOf(value1-value2));}
            case "+" : {seq1.get(0).push(String.valueOf(value1-value2));}
        }

    }

    public void zdruzi() throws CollectionException{
        String string1= this.seq1.get(0).pop();
        String string2= this.seq1.get(0).pop();
        seq1.get(0).push(string1+string2);
    }

    public void randomnum() throws CollectionException{
        int value1= Integer.parseInt(seq1.get(0).pop());
        int value2= Integer.parseInt(seq1.get(0).pop());

        int d = (int) ((Math.random() * (value2 - value1)) + value1);
        seq1.get(0).push(String.valueOf(d));
    }

    public void then() throws CollectionException{
        int value1= Integer.parseInt(seq1.get(0).pop());
        if ( value1 != 0){
            condition = true;
        }
        else{ condition=false;}
    }

    public void else1() throws CollectionException{
        if (condition ){ condition = false;}
        else{condition=true;}
    }


    public void  print1() throws CollectionException{
        int i=0;
        int value1= Integer.parseInt(seq1.get(0).pop());
        while(!seq1.get(value1).isEmpty()){
            seq1.get(value1).pop();
            seq1.get(0).push(seq1.get(value1).pop());
            i+=1;
        }
        while(i > 0){
            seq1.get(value1).push(seq1.get(0).pop());
            i-=1;
        }
    }
    public void isprazni() throws CollectionException{
        int value1= Integer.parseInt(seq1.get(0).pop());
        while(!seq1.get(value1).isEmpty()){
              seq1.get(value1).pop();
        }
    }







    private void funkcii(String s) throws CollectionException{
        switch(s){
            case "echo" : echo(); break; case "char": character();break; case "<>": pogolemopomalo();break;
            case "dup" : dup(); break; case "!" : factorial();break; case "<": pomalo(); break;
            case "pop": pop(); break; case "len": length1();break; case ">": pogolemo();break;
            case "dup2": dup2();break; case "even" : even(); break; case "==": ednakvo();break;
            case "swap": swap(); break; case "odd": odd(); break; case "<=": pomaloednakvo();break;
            case ">=": pogolemoednakvo();break; case ".": zdruzi();break; case "rand" : randomnum();break;
            case "%" : case "/" : case "*" :  case "-" : case "+" : operacii(s);break; case "print": print1();break;
            case "then" : then();break; case "else": else1();break; case "clear" : isprazni();break;
            default: seq1.get(0).push(s);


            }
        }




    public ProgramabilniKalkulator1(String[] line) throws CollectionException{
        seq1= new ArrayDeque<>();
        for (int i=0;i<42; i++){
            Stack<String> stack= new ArrayDeque<>();
            this.seq1.add(stack);
        }


        for(int i=0; i< line.length; i++){
            String s= line[i];
            if (!s.matches("^[?].*$")) {
                funkcii(s);

            }
            else {
                s = s.substring(1);
                if (condition) {
                    funkcii(s);
                }
            }


        }

    }



    public static void main(String args[]) throws CollectionException {
         Scanner scan1=  new Scanner(System.in);
         while (scan1.hasNextLine()){
             new ProgramabilniKalkulator1(scan1.nextLine().split(" "));
         }




        }





}
