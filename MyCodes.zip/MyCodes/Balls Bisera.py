import risar
from math import *
from random import  choice, randint
import time

class Zoge():
    def __init__(self):
        self.x0=randint(10,risar.maxX-10)
        self.y0=randint(10,risar.maxY-10)
        self.barva=risar.nakljucna_barva()
        self.circle = risar.krog(self.x0, self.y0, 10, self.barva)
        self.vx=randint(-5,5)
        self.vy= (sqrt(25 - self.vx **2))*choice((1,-1))
        self.exploded_balls={}

def new_cursor_ball():
    x0,y0 = risar.miska
    return risar.krog(x0,y0,30, barva= risar.bela, sirina = 1)

def nova_zoga(stzoge):
    risar.maxX = risar.widget.view.width()
    risar.maxY = risar.widget.view.height()
    movtzoga = False
    movzoga = new_cursor_ball()
    igra = mov =True
    listzoge = []
    for i in range(stzoge):
        listzoge.append(Zoge())
    while igra:
        if (mov):
            xp, yp = risar.miska
            movzoga.setPos(xp, yp)
        for i in range(len(listzoge)):
            zoga=listzoge[i]
            zoga.circle.setPos(zoga.circle.x() + zoga.vx, zoga.circle.y() + zoga.vy)
            if not 0 < zoga.circle.x() < risar.maxX:
                zoga.vx = -zoga.vx
            if not 0 < zoga.circle.y() < risar.maxY:
                zoga.vy = -zoga.vy
            if risar.klik:
                mov = False
                if (0<sqrt((xp  - zoga.circle.x()) ** 2 + (yp - zoga.circle.y() ** 2) <= (risar.maxX + risar.maxY))):
                    movtzoga = True
        if (movtzoga):
            break
        time.sleep(0.02)
        risar.obnovi()
    risar.stoj()

nova_zoga(30)

