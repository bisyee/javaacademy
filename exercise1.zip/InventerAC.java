package com.cosylab.academy.exercise1;

public class InventerAC extends NormalAC{
    private static int preferredTemp;
    private static int state=1;


    public static void main(String[] args) {

        NormalAC.ConditionerState();//user turning on and off the air conditioner
        NormalAC.PreferredTemperature(); //user writing the preferred temperature
        NormalAC.startCooling(checkCooling(), 20.0D, 10.0D); //start cooling if cooling is necessary

    }

}
