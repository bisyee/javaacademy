package com.cosylab.academy.exercise1;

import com.cosylab.academy.java.provided.exercise1.Room;

public class HelloWorld {

    /**
     * Prints 'Hello World!' to STDOUT
     * @param args program arguments passed from command-line
     */
    public static void main(String[] args) {
        // Lets retrieve the Room!
        Room.getDefaultInstance();
        System.out.println("Hello World!");
    }
}
