package com.cosylab.academy.exercise1;
import java.util.Scanner;
import com.cosylab.academy.java.provided.exercise1.Room;
public class NormalAC {
//Non inventor works only if cooling is necessary ( Works with start and stop- MAX power when working, 0 when not working)

    private static int preferredTemp;
    private static int state=0;

    public static void ConditionerState() {
        try
        {
            Scanner sc = new Scanner(System.in); //Input stream
            System.out.print("Enter the State of the Air Conditioner: (Note: 1 means turned on, 0 means turned off) ");
            int x = Integer.parseInt(sc.nextLine());
            if(state == 0 && x == 0 || state == 1 && x == 1){ //Checking if there isn't any illegal operation like turning on the  AC if it is already turned on and vice versa

                System.out.print("That is not allowed! You can only turn on the AC if it was turned off and vice versa");
                ConditionerState();
            }
            if(x != 0 && x != 1){ //Checking if the input is only 1 or 0
                System.out.print("Incorrect input! Please try again!");
                ConditionerState();
            }
            }
        catch (NumberFormatException ex) // Throwing exception if the user's input is not integer
        {
            System.out.println("Invalid input! You have to enter a number");
            ConditionerState();
        }
    }

    public static void PreferredTemperature() {
        try
        {
            Scanner sc = new Scanner(System.in); //Input stream
            System.out.print("Enter your preferred temperature: ");
            preferredTemp = Integer.parseInt(sc.nextLine());
            if(preferredTemp < 12){ //Throwing error  if the temperature is lower than 10
               System.out.println("That is too cold!");
                PreferredTemperature();
            }
            if(preferredTemp > 30 ) { //Throwing error  if the temperature is more than 30
                System.out.println("That is too hot!");
                PreferredTemperature();
            }
        }
        catch (NumberFormatException ex) // Exception if it is not a number
            {
                System.out.println("Invalid input! You have to enter a number");
                PreferredTemperature();
            }
    }
    public static boolean checkCooling(){
        boolean state1 = false;
        double currentTemp = Room.getDefaultInstance().getCurrentTemperature(); //read the current room temperature
        if (currentTemp > preferredTemp) { //checking if the current temperature of the room is bigger than preferred. IF it is cooling is necessary
            System.out.print("Cooling is necessary");
            state1 = true;
            if(state == 0) { //Checking if the AC is turned on
                state = 1; // Turning it on if it is not already turned on
            }
        } else{
            state = 0; // If cooling is not necessary, the AC is turned off and the Cooling power is set to 0
            Room.getDefaultInstance().setCoolingPower(0);

        }
        return state1;
    }

    public static void startCooling(boolean x, double maxPower, double minPower){
        if(x){
            if (state != 1) { //Turning on the AC, if it is not already turned on and setting the cooling power to MAX power
                state = 1;
            }
            Room.getDefaultInstance().setCoolingPower(maxPower);
        } else{
            state =0;
            Room.getDefaultInstance().setCoolingPower(minPower);
        }
    }

    public static void main(String[] args) {

        ConditionerState();//user turning on and off the air conditioner
        PreferredTemperature(); //user writing the preferred temperature
        startCooling(checkCooling(), 100.0D, 0.0D); //start cooling if cooling is necessary

    }
}
